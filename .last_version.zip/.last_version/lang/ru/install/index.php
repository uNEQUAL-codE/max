<?php
$MESS['KDIGITALS_KDIGITALS_MODULE_NAME'] = 'Онлайн-чат МАКС';
$MESS['KDIGITALS_KDIGITALS_MODULE_DESC'] = 'Онлайн-чат сайта с доставкой сообщений в приватный чат или канал MAX';
