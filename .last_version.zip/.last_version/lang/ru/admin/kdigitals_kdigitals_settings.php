<?php
$MESS['KDIGITALS_KDIGITALS_SETTINGS_TITLE']='Онлайн-чат МАКС — настройки';
