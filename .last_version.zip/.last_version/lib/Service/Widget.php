<?php
namespace Resurs\Kdigitals\Service;

final class Widget
{
    public static function render(): string
    {
        if (!Settings::enabled()) {
            return '';
        }

        $cfg = [
            'endpoint' => '/bitrix/tools/kdigitals.max/ajax.php',
            'title' => Settings::widgetTitle(),
            'subtitle' => Settings::get('subtitle', 'Мы отвечаем через MAX'),
            'greeting' => Settings::greeting(),
            'buttonText' => Settings::get('button_text', 'Чат'),
            'position' => Settings::get('position', 'right'),
            'color' => Settings::get('color', '#471AFF'),
            'headerColor2' => Settings::get('header_color_2', '#00BFFF'),
            'buttonSize' => (int)Settings::get('button_size', '66'),
            'borderRadius' => (int)Settings::get('border_radius', '22'),
            'offsetX' => (int)Settings::get('offset_x', '24'),
            'offsetY' => (int)Settings::get('offset_y', '24'),
            'avatarUrl' => Settings::get('avatar_url', '/bitrix/js/kdigitals.max/max-icon.svg'),
            'buttonIconUrl' => Settings::get('button_icon_url', '/bitrix/js/kdigitals.max/max-icon.svg'),
            'avatarShape' => Settings::get('avatar_shape', 'square') === 'circle' ? 'circle' : 'square',
            'avatarZoom' => max(100, min(200, (int)Settings::get('avatar_zoom', '100'))),
            'avatarX' => max(0, min(100, (int)Settings::get('avatar_x', '50'))),
            'avatarY' => max(0, min(100, (int)Settings::get('avatar_y', '50'))),
            'buttonIconShape' => Settings::get('button_icon_shape', 'circle') === 'square' ? 'square' : 'circle',
            'buttonIconZoom' => max(100, min(200, (int)Settings::get('button_icon_zoom', '100'))),
            'buttonIconX' => max(0, min(100, (int)Settings::get('button_icon_x', '50'))),
            'buttonIconY' => max(0, min(100, (int)Settings::get('button_icon_y', '50'))),
            'managerName' => Settings::managerName(),
            'workStartTime' => Settings::get('work_start_time', '09:00'),
            'workEndTime' => Settings::get('work_end_time', '17:00'),
        ];
        $json = htmlspecialchars(
            json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ENT_QUOTES,
            'UTF-8'
        );

        // Version the public assets so browsers/CDNs cannot keep an older
        // widget.js/widget.css after an admin-side design change or module update.
        $assetVersion = '0.4.56';
        return '<div id="resurs-kdigitals" style="visibility:hidden;--rmc-size:' . (int)$cfg['buttonSize'] . 'px;--rmc-radius:' . (int)$cfg['borderRadius'] . 'px;--rmc-offset-x:' . (int)$cfg['offsetX'] . 'px;--rmc-offset-y:' . (int)$cfg['offsetY'] . 'px;"></div>'
            . '<link rel="stylesheet" href="/bitrix/js/kdigitals.max/widget.css?v=' . $assetVersion . '">'
            . '<script>window.KDIGITALS_KDIGITALS=' . $json . ';</script>'
            . '<script src="/bitrix/js/kdigitals.max/widget.js?v=' . $assetVersion . '" defer></script>';
    }
}
