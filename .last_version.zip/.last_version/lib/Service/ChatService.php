<?php
namespace Resurs\Kdigitals\Service;
use Bitrix\Main\Context;
use Bitrix\Main\Type\DateTime;
use Resurs\Kdigitals\Api\MaxApi;
use Resurs\Kdigitals\Model\ConversationTable;
use Resurs\Kdigitals\Model\MessageTable;
use Resurs\Kdigitals\Model\VisitorTable;
use RuntimeException;
final class ChatService
{
    public static function visitor(string $visitorKey): int
    {
        $request=Context::getCurrent()->getRequest(); $siteId=defined('SITE_ID')?SITE_ID:'s1'; $ip=(string)$request->getRemoteAddress();
        $row=VisitorTable::getRow(['filter'=>['=SITE_ID'=>$siteId,'=VISITOR_KEY'=>$visitorKey]]);
        $fields=['SITE_ID'=>$siteId,'VISITOR_KEY'=>$visitorKey,'SESSION_ID'=>session_id(),'IP'=>$ip,'IP_HASH'=>hash('sha256',$ip.'|'.Settings::get('ip_hash_salt')),'USER_AGENT'=>mb_substr((string)$request->getUserAgent(),0,10000),'LAST_PAGE'=>mb_substr((string)$request->getRequestUri(),0,2048),'UPDATED_AT'=>new DateTime()];
        if($row){VisitorTable::update($row['ID'],$fields);return (int)$row['ID'];}
        $fields['FIRST_PAGE']=$fields['LAST_PAGE'];$fields['CREATED_AT']=new DateTime();return (int)VisitorTable::add($fields)->getId();
    }
    public static function open(string $visitorKey,string $pageUrl):array
    {
        if(Settings::chatId()==='') throw new RuntimeException('В настройках MAX Chat не указан ID приватного чата/канала.');
        $visitorId=self::visitor($visitorKey); $conversation=ConversationTable::getRow(['filter'=>['=VISITOR_ID'=>$visitorId,'=STATUS'=>'OPEN'],'order'=>['ID'=>'DESC']]);
        if(!$conversation){$r=ConversationTable::add(['SITE_ID'=>defined('SITE_ID')?SITE_ID:'s1','VISITOR_ID'=>$visitorId,'MAX_CHAT_ID'=>Settings::chatId(),'STATUS'=>'OPEN','PAGE_URL'=>mb_substr($pageUrl,0,2048)]);$conversation=ConversationTable::getById($r->getId())->fetch();}
        return $conversation;
    }
    public static function send(int $conversationId,string $text,string $clientMessageId='',?array $file=null,string $visitorName='',string $visitorKey=''):array
    {
        if($visitorKey==='' || strlen($visitorKey)>128 || !preg_match('/^[a-zA-Z0-9_-]{20,128}$/D',$visitorKey)) throw new RuntimeException('Доступ запрещён.');
        $conversation=self::ownedConversation($conversationId,$visitorKey);
        if(!$conversation)throw new RuntimeException('Доступ запрещён.');
        $text=trim($text);
        $visitorName='Пользователь';
        if($text==='' && empty($file))throw new RuntimeException('Введите сообщение или прикрепите файл.');
        if(mb_strlen($text)>4000)throw new RuntimeException('Сообщение должно содержать не более 4000 символов.');
        if($file) {
            if ((int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Не удалось загрузить файл.');
            }
            $tmpName = (string)($file['tmp_name'] ?? '');
            $reportedSize = (int)($file['size'] ?? 0);
            if ($tmpName === '' || !is_uploaded_file($tmpName) || !is_file($tmpName)) {
                throw new RuntimeException('Некорректный загруженный файл.');
            }
            $actualSize = filesize($tmpName);
            if ($actualSize === false || $actualSize <= 0 || $actualSize > 52428800 || $reportedSize !== (int)$actualSize) {
                throw new RuntimeException('Файл должен быть размером от 1 байта до 50 МБ.');
            }
            $originalName = (string)($file['name'] ?? '');
            if ($originalName === '' || preg_match('/[\\\\\/\\x00-\\x1F]/', $originalName)) {
                throw new RuntimeException('Некорректное имя файла.');
            }
        }
        $clientMessageId=preg_replace('/[^a-zA-Z0-9_-]/','',mb_substr($clientMessageId,0,64));

        // Idempotency lock: two AJAX requests with the same client_message_id
        // must never both reach MAX. This also protects against double clicks,
        // duplicated JS handlers and browser/network retries.
        $lockHandle=null;
        if($clientMessageId!==''){
            $lockDir=$_SERVER['DOCUMENT_ROOT'].'/bitrix/cache/kdigitals.max';
            if(!is_dir($lockDir))@mkdir($lockDir,0775,true);
            $lockFile=$lockDir.'/send_'.sha1($conversationId.'|'.$clientMessageId).'.lock';
            $lockHandle=@fopen($lockFile,'c');
            if($lockHandle)@flock($lockHandle,LOCK_EX);
        }
        try{
            if($clientMessageId!==''){
                $existing=MessageTable::getRow(['filter'=>['=CONVERSATION_ID'=>$conversationId,'=CLIENT_MESSAGE_ID'=>$clientMessageId]]);
                if($existing){
                    return ['message_id'=>(string)($existing['MAX_MESSAGE_ID']??''),'duplicate'=>true];
                }
            }

            // Reserve the client message BEFORE calling MAX. This closes the
            // race where two identical AJAX requests both checked the database
            // and then both sent the same text to MAX.
            $reservationFields=[
                'CONVERSATION_ID'=>$conversationId,
                'DIRECTION'=>'OUT',
                'SENDER_TYPE'=>'VISITOR',
                'MESSAGE_TEXT'=>$text,
                'MAX_MESSAGE_ID'=>null,
                'CLIENT_MESSAGE_ID'=>$clientMessageId!==''?$clientMessageId:null,
                'RAW_JSON'=>json_encode(['status'=>'pending'],JSON_UNESCAPED_UNICODE),
                'CREATED_AT'=>new DateTime(),
            ];
            $reservation=MessageTable::add($reservationFields);
            if(!$reservation->isSuccess()){
                if($clientMessageId!==''){
                    $existing=MessageTable::getRow(['filter'=>['=CONVERSATION_ID'=>$conversationId,'=CLIENT_MESSAGE_ID'=>$clientMessageId]]);
                    if($existing)return ['message_id'=>(string)($existing['MAX_MESSAGE_ID']??''),'duplicate'=>true];
                }
                throw new RuntimeException(implode('; ',$reservation->getErrorMessages()));
            }
            $localMessageId=(int)$reservation->getId();

            try{
                // URL страницы хранится внутри Bitrix для истории, но НЕ отправляется в MAX.
                $visitor=VisitorTable::getById($conversation['VISITOR_ID'])->fetch();
                VisitorTable::update((int)$conversation['VISITOR_ID'], ['VISITOR_NAME'=>$visitorName,'UPDATED_AT'=>new DateTime()]);
                $visitorCode=strtoupper(substr(hash('sha256',(string)$visitor['VISITOR_KEY']),0,6));
                $visitorIp=trim((string)($visitor['IP']??''));
                $prefix='🟣 ОБРАЩЕНИЕ #'.$conversationId.' · '.$visitorCode."\n";
                $body=$prefix."\n**От кого:** Пользователь"."\n\n**IP-Адресс:** ".$visitorIp."\n\n**Сообщение:** ".$text."\n\n↩️  Ответьте на ЭТО сообщение в MAX — тогда ответ уйдёт только этому посетителю.";
                $api=new MaxApi();
                $attachment=null;
                if($file){
                    $name=basename((string)($file['name']??'file'));
                    $size=(int)($file['size']??0);
                    if($size<=0 || $size>52428800) throw new RuntimeException('Файл должен быть размером не более 50 МБ.');
                    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
                    $imageExt=['jpg','jpeg','png','gif','tif','tiff','bmp','heic'];
                    $type=in_array($ext,$imageExt,true)?'image':'file';
                    if($type==='file' && $size>52428800) throw new RuntimeException('Документ должен быть размером не более 50 МБ.');
                    $mime='application/octet-stream';
                    if (class_exists('finfo')) {
                        $finfo = new \finfo(FILEINFO_MIME_TYPE);
                        $detected = $finfo->file((string)$file['tmp_name']);
                        if (is_string($detected) && $detected !== '') $mime = $detected;
                    }
                    $up=$api->uploadFile((string)$file['tmp_name'],$mime,$type,$name);
                    usleep(700000);
                    $result=$api->sendAttachment((string)$conversation['MAX_CHAT_ID'],$body,$type,$up['token']);
                    $attachment=['type'=>$type,'name'=>$name,'size'=>$size];
                }else{
                    $result=$api->sendMessage((string)$conversation['MAX_CHAT_ID'],$body);
                }
                $mid=(string)($result['message']['body']['mid']??'');
                MessageTable::update($localMessageId,[
                    'MAX_MESSAGE_ID'=>$mid?:null,
                    'RAW_JSON'=>json_encode(['max'=>$result,'attachment'=>$attachment],JSON_UNESCAPED_UNICODE),
                ]);
                ConversationTable::update($conversationId,['UPDATED_AT'=>new DateTime()]);
                return ['message_id'=>$mid,'max'=>$result,'duplicate'=>false];
            }catch(\Throwable $e){
                MessageTable::delete($localMessageId);
                throw $e;
            }
        }finally{
            if($lockHandle){@flock($lockHandle,LOCK_UN);@fclose($lockHandle);}
        }
    }
    /**
     * Return a conversation only when the supplied high-entropy browser key
     * matches the visitor record that owns this conversation.
     */
    private static function ownedConversation(int $conversationId,string $visitorKey): ?array
    {
        if($conversationId<=0 || $visitorKey==='' || strlen($visitorKey)>128) return null;
        $visitor=VisitorTable::getRow(['filter'=>[
            '=SITE_ID'=>(defined('SITE_ID')?SITE_ID:'s1'),
            '=VISITOR_KEY'=>$visitorKey,
        ]]);
        if(!$visitor) return null;
        return ConversationTable::getRow(['filter'=>[
            '=ID'=>$conversationId,
            '=VISITOR_ID'=>(int)$visitor['ID'],
            '=SITE_ID'=>(defined('SITE_ID')?SITE_ID:'s1'),
        ]]);
    }

    public static function messages(int $conversationId,int $afterId=0,string $visitorKey=''):array
    {
        if($afterId<0 || $afterId>PHP_INT_MAX) return [];
        $conversation=self::ownedConversation($conversationId,$visitorKey);
        if(!$conversation) throw new RuntimeException('Доступ запрещён.');
        $rows=MessageTable::getList(['filter'=>['=CONVERSATION_ID'=>$conversationId,'>ID'=>$afterId],'order'=>['ID'=>'ASC'],'limit'=>100])->fetchAll();
        foreach($rows as &$row){ $raw=json_decode((string)($row['RAW_JSON']??''),true); $row['ATTACHMENTS']=is_array($raw)&&isset($raw['attachment'])?[ $raw['attachment'] ]:[]; $row['SENDER_NAME']=($row['SENDER_TYPE']==='MANAGER')?Settings::managerName():'Пользователь'; }
        
        return $rows;
    }
}
