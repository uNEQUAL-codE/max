<?php
namespace Resurs\Kdigitals\Service;

// RegisterModuleDependences can call this file directly via TO_PATH, including
// installations located in /local/modules as well as /bitrix/modules.
$moduleRoot = dirname(__DIR__, 2);
$includeFile = $moduleRoot . '/include.php';
if (is_file($includeFile)) {
    require_once $includeFile;
}

final class EventHandler
{
    public static function onEndBufferContent(&$content): void
    {
        if (defined('ADMIN_SECTION') && ADMIN_SECTION === true) {
            return;
        }
        if (PHP_SAPI === 'cli' || !is_string($content) || stripos($content, '</body>') === false) {
            return;
        }
        if (stripos($content, 'resurs-kdigitals') !== false) {
            return;
        }

        try {
            $widget = Widget::render();
            if ($widget === '') {
                return;
            }
            $content = str_ireplace('</body>', $widget . '</body>', $content);
        } catch (\Throwable $e) {
            // Never break the public site because of the chat module.
        }
    }
}
