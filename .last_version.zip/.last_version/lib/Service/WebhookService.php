<?php
namespace Resurs\Kdigitals\Service;
use Bitrix\Main\Type\DateTime;
use Resurs\Kdigitals\Api\MaxApi;
use Resurs\Kdigitals\Model\ChatTable;
use Resurs\Kdigitals\Model\ConversationTable;
use Resurs\Kdigitals\Model\MessageTable;
final class WebhookService
{
    private static function findLinkedMid(array $message): string
    {
        $link = $message['link'] ?? null;
        if (!is_array($link)) return '';
        // Only a real reply is a safe routing signal. Forwarded messages
        // must never be used to guess the visitor conversation.
        $type = strtolower((string)($link['type'] ?? ''));
        if ($type !== 'reply') return '';
        if (!empty($link['message']['mid'])) return (string)$link['message']['mid'];
        if (!empty($link['mid'])) return (string)$link['mid'];
        if (!empty($link['message_id'])) return (string)$link['message_id'];
        return '';
    }

    private static function linkedConversation(string $mid): ?array
    {
        if ($mid === '') return null;
        $mapped = MessageTable::getRow(['filter' => ['=MAX_MESSAGE_ID' => $mid]]);
        if (!$mapped) return null;
        return ConversationTable::getById((int)$mapped['CONVERSATION_ID'])->fetch() ?: null;
    }

    public static function handle(array $payload):void
    {
        $update=$payload['update']??$payload; $type=(string)($update['update_type']??$update['type']??'');
        if(in_array($type,['bot_added','bot_removed','bot_admin_permissions_changed'],true)){
            $chatId=(string)($update['chat_id']??''); if($chatId==='')return;
            if($type==='bot_removed'){if($row=ChatTable::getRow(['filter'=>['=MAX_CHAT_ID'=>$chatId]]))ChatTable::update($row['ID'],['ACTIVE'=>'N','UPDATED_AT'=>new DateTime()]);return;}
            $title='';$chatType='';$isChannel=!empty($update['is_channel'])?'Y':'N';
            try{$chat=(new MaxApi())->getChat($chatId);$title=(string)($chat['title']??'');$chatType=(string)($chat['type']??'');$isChannel=($chatType==='channel')?'Y':$isChannel;}catch(\Throwable $e){}
            $row=ChatTable::getRow(['filter'=>['=MAX_CHAT_ID'=>$chatId]]);
            $fields=['MAX_CHAT_ID'=>$chatId,'TYPE'=>$chatType,'TITLE'=>$title,'IS_CHANNEL'=>$isChannel,'ACTIVE'=>'Y','UPDATED_AT'=>new DateTime()];
            if($row)ChatTable::update($row['ID'],$fields);else{ $fields['CREATED_AT']=new DateTime();ChatTable::add($fields); }
            return;
        }
        if($type!=='message_created')return;
        $message=$update['message']??$update['message_created']??null;if(!is_array($message))return;
        $chatId=(string)($message['recipient']['chat_id']??$update['chat_id']??$message['chat_id']??'');
        if($chatId===''||($configured=Settings::chatId())===''||$chatId!==$configured)return;
        // Do not process the bot's own messages.
        if (!empty($message['sender']['is_bot'])) return;
        $mid=(string)($message['body']['mid']??$message['id']??'');
        if($mid!==''&&MessageTable::getRow(['filter'=>['=MAX_MESSAGE_ID'=>$mid]]))return;
        $body=(array)($message['body']??[]);
        $text=(string)($body['text']??'');
        // MAX can put attachment/caption formatting into the text as repeated
        // blank lines. Keep meaningful line breaks, but remove empty padding
        // around screenshot/file messages so the widget does not show a large
        // empty area before the attachment.
        $text=str_replace(["\r\n","\r"],"\n",$text);
        $text=preg_replace('/[ \t]+\n/u',"\n",$text);
        $text=preg_replace('/\n[ \t]+/u',"\n",$text);
        $text=preg_replace('/\n{2,}/u',"\n",$text);
        $text=trim($text);
        $attachments=(array)($body['attachments']??[]);
        if($text==='' && !$attachments)return;

        // IMPORTANT: in a shared MAX operator chat there can be many visitors
        // at the same time. We NEVER guess which visitor should receive a
        // standalone manager message. Only a MAX "Reply" link can route it.
        $linked=self::findLinkedMid($message);
        $conversation=self::linkedConversation($linked);
        if(!$conversation){
            // Explicit routing code is supported as a manual fallback, but
            // only when the manager starts the message with #ID. It is never
            // inferred from arbitrary message text.
            if(preg_match('/^\s*#(\d+)\b/u',$text,$m)){
                $conversation=ConversationTable::getById((int)$m[1])->fetch() ?: null;
                if($conversation){
                    $text=preg_replace('/^\s*#(\d+)\b[\s:,-]*/u','',$text);
                }
            }
        }
        if(!$conversation){
            // Ambiguous manager message: keep it out of all visitor chats.
            return;
        }
        // Webhook attachments can contain only a token. Fetch the canonical message
        // by mid so MAX can return the complete attachment representation (including
        // an image URL when available).
        if($mid!=='' && $attachments){
            try {
                $api=new \Resurs\Kdigitals\Api\MaxApi();
                $full=$api->getMessage($mid);
                $fullBody=(array)($full['body']??[]);
                if(array_key_exists('text',$fullBody)){
                    $text=(string)$fullBody['text'];
                    $text=str_replace(["\r\n","\r"],"\n",$text);
                    $text=preg_replace('/[ \t]+\n/u',"\n",$text);
                    $text=preg_replace('/\n[ \t]+/u',"\n",$text);
                    $text=preg_replace('/\n{2,}/u',"\n",$text);
                    $text=trim($text);
                }
                if(!empty($fullBody['attachments']) && is_array($fullBody['attachments'])) $attachments=$fullBody['attachments'];
            } catch (\Throwable $e) {
                // Keep the webhook representation if the follow-up request is unavailable.
            }
        }
        $safeAttachments=[]; foreach($attachments as $att){
            if(!is_array($att))continue;
            $type=(string)($att['type']??'file');
            $payloadAtt=(array)($att['payload']??[]);
            $url=(string)($att['url'] ?? '');
            if($url==='') $url=(string)($att['download_url'] ?? ($att['downloadUrl'] ?? ''));
            if($url==='') $url=(string)($payloadAtt['url'] ?? ($payloadAtt['download_url'] ?? ($payloadAtt['downloadUrl'] ?? '')));
            if($url==='') $url=(string)($payloadAtt['file_url'] ?? ($payloadAtt['fileUrl'] ?? ($payloadAtt['src'] ?? '')));
            $name=(string)($att['name'] ?? ($att['filename'] ?? ($att['file_name'] ?? ($att['fileName'] ?? ''))));
            if($name==='') $name=(string)($payloadAtt['name'] ?? ($payloadAtt['filename'] ?? ($payloadAtt['file_name'] ?? ($payloadAtt['fileName'] ?? ''))));
            if($name==='') $name=(string)($att['text'] ?? '');
            if($name==='') $name=$type==='image'?'Изображение':($type==='file'?'Файл':'Вложение');
            $safeAttachments[]=['type'=>$type,'url'=>$url,'name'=>$name,'payload'=>$payloadAtt];
        }
        MessageTable::add(['CONVERSATION_ID'=>$conversation['ID'],'DIRECTION'=>'IN','SENDER_TYPE'=>'MANAGER','MESSAGE_TEXT'=>$text,'MAX_MESSAGE_ID'=>$mid?:null,'RAW_JSON'=>json_encode(['payload'=>$payload,'attachments'=>$safeAttachments,'sender_name'=>Settings::managerName()],JSON_UNESCAPED_UNICODE),'CREATED_AT'=>new DateTime()]);
        ConversationTable::update($conversation['ID'],['UPDATED_AT'=>new DateTime()]);
    }
}
