<?php
namespace Resurs\Kdigitals\Service;
use Bitrix\Main\Config\Option;
final class Settings
{
    private const MODULE_ID = 'kdigitals.max';
    public static function get(string $name, string $default = ''): string { return (string)Option::get(self::MODULE_ID, $name, $default); }
    public static function set(string $name, string $value): void { Option::set(self::MODULE_ID, $name, $value); }
    public static function token(): string { return self::get('access_token'); }
    public static function chatId(): string { return self::get('max_chat_id'); }
    public static function webhookSecret(): string { return self::get('webhook_secret'); }
    public static function enabled(): bool { return self::get('enabled','Y') === 'Y'; }
    public static function widgetTitle(): string { return self::get('title','Онлайн-консультант'); }
    public static function greeting(): string { return self::get('greeting','Здравствуйте! Напишите нам, и мы ответим в MAX.'); }
    public static function managerName(): string { return self::get('manager_name','Администратор'); }

    /** Reset all module options, including widget appearance and MAX connection credentials. */
    public static function resetAll(): void
    {
        Option::delete(self::MODULE_ID);
        self::clearPublicCache();
    }

    /**
     * Public pages may be served from Bitrix component/static HTML cache.
     * Settings changed in the admin must therefore invalidate public cache,
     * otherwise the old widget configuration can remain visible until TTL.
     */
    public static function clearPublicCache(): void
    {
        try {
            if (function_exists('BXClearCache')) {
                BXClearCache(true);
            }
        } catch (\Throwable $e) {}

        try {
            if (class_exists('\Bitrix\Main\Data\StaticHtmlCache')) {
                \Bitrix\Main\Data\StaticHtmlCache::getInstance()->deleteAll();
            }
        } catch (\Throwable $e) {}

        try {
            if (class_exists('\Bitrix\Main\Data\ManagedCache')) {
                (new \Bitrix\Main\Data\ManagedCache())->cleanAll();
            }
        } catch (\Throwable $e) {}
    }
}
