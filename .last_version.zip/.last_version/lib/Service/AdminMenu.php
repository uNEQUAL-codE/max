<?php
namespace Resurs\Kdigitals\Service;

final class AdminMenu
{
    public static function onBuildGlobalMenu(&$aGlobalMenu, &$aModuleMenu): void
    {
        if (isset($GLOBALS['APPLICATION']) && is_object($GLOBALS['APPLICATION'])) {
            $GLOBALS['APPLICATION']->SetAdditionalCSS('/bitrix/themes/.default/kdigitals_kdigitals.css');
        }
        // Dedicated top-level MAX section so it is immediately visible in
        // the Bitrix admin navigation instead of being hidden inside Settings.
        $aGlobalMenu['global_menu_kdigitals_kdigitals'] = [
            'menu_id' => 'kdigitals_kdigitals',
            'text' => 'Онлайн-чат МАКС',
            'title' => 'Онлайн-чат МАКС — обращения с сайта',
            'sort' => 605,
            'items_id' => 'kdigitals_kdigitals',
            'icon' => 'kdigitals_kdigitals_menu_icon',
            'page_icon' => 'kdigitals_kdigitals_page_icon',
            'help_section' => 'kdigitals_kdigitals',
            'items' => [],
        ];

        $aModuleMenu[] = [
            'parent_menu' => 'global_menu_kdigitals_kdigitals',
            'sort' => 10,
            'text' => 'Обзор',
            'title' => 'Общий обзор и настройки Онлайн-чата МАКС',
            'url' => 'kdigitals_kdigitals_settings.php?tab=dashboard&lang='.LANGUAGE_ID,
            'items_id' => 'kdigitals_kdigitals_overview',
            'module_id' => 'kdigitals.max',
        ];
        $aModuleMenu[] = [
            'parent_menu' => 'global_menu_kdigitals_kdigitals',
            'sort' => 20,
            'text' => 'Подключение MAX',
            'title' => 'Подключение MAX API и Webhook',
            'url' => 'kdigitals_kdigitals_settings.php?tab=connection&lang='.LANGUAGE_ID,
            'module_id' => 'kdigitals.max',
        ];
        $aModuleMenu[] = [
            'parent_menu' => 'global_menu_kdigitals_kdigitals',
            'sort' => 30,
            'text' => 'Редактор виджета',
            'title' => 'Внешний вид и тексты виджета',
            'url' => 'kdigitals_kdigitals_settings.php?tab=widget&lang='.LANGUAGE_ID,
            'module_id' => 'kdigitals.max',
        ];
        $aModuleMenu[] = [
            'parent_menu' => 'global_menu_kdigitals_kdigitals',
            'sort' => 40,
            'text' => 'Дополнительно',
            'title' => 'Дополнительные параметры',
            'url' => 'kdigitals_kdigitals_settings.php?tab=advanced&lang='.LANGUAGE_ID,
            'module_id' => 'kdigitals.max',
        ];
    }
}
