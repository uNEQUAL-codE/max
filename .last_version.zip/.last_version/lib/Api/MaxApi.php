<?php
namespace Resurs\Kdigitals\Api;
use Bitrix\Main\Web\HttpClient;
use Resurs\Kdigitals\Service\Settings;
use RuntimeException;
final class MaxApi
{
    private const BASE_URL = 'https://platform-api2.max.ru';
    private function request(string $method, string $path, ?array $body = null, array $query = []): array
    {
        $client = new HttpClient(['socketTimeout'=>20,'streamTimeout'=>20,'disableSslVerification'=>false]);
        $client->setHeader('Authorization', Settings::token());
        $client->setHeader('Content-Type', 'application/json');
        $url = self::BASE_URL . $path;
        if ($query) $url .= '?' . http_build_query($query);
        $payload = $body === null ? null : json_encode($body, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $attempts = 0;
        do {
            $response = match (strtoupper($method)) {
                'GET' => $client->get($url),
                'POST' => $client->post($url, $payload),
                'PUT' => $client->put($url, $payload),
                'PATCH' => $client->query('PATCH', $url, $payload),
                'DELETE' => $client->query('DELETE', $url, $payload),
                default => throw new RuntimeException('Unsupported HTTP method'),
            };
            $status = $client->getStatus();
            $raw = (string)$response;

            // MAX ограничивает отправку до 2 сообщений в секунду в один диалог.
            // При 429/503 не теряем сообщение: повторяем запрос с нарастающей паузой.
            if (($status === 429 || $status === 503) && strtoupper($method) === 'POST' && $attempts < 3) {
                $attempts++;
                usleep(650000 * $attempts);
                continue;
            }
            break;
        } while (true);

        $data = json_decode($raw, true);
        if ($status < 200 || $status >= 300) throw new RuntimeException('MAX API HTTP '.$status.': '.$raw);
        return is_array($data) ? $data : [];
    }
    public function me(): array { return $this->request('GET','/me'); }
    public function getChat(string $chatId): array { return $this->request('GET','/chats/'.rawurlencode($chatId)); }
    public function getMessage(string $messageId): array { return $this->request('GET','/messages/'.rawurlencode($messageId)); }
    public function uploadFile(string $tmpPath, string $mime, string $type, string $name = ''): array
    {
        if (!is_file($tmpPath)) throw new RuntimeException('Файл не найден.');
        $client = new HttpClient(['socketTimeout'=>120,'streamTimeout'=>120,'disableSslVerification'=>false]);
        $client->setHeader('Authorization', Settings::token());
        $init = $client->post(self::BASE_URL.'/uploads?type='.rawurlencode($type), '');
        $status = $client->getStatus();
        $data = json_decode((string)$init, true);
        if ($status < 200 || $status >= 300 || !is_array($data) || empty($data['url'])) {
            throw new RuntimeException('MAX upload init HTTP '.$status.': '.(string)$init);
        }
        $uploadUrl = (string)$data['url'];
        $ch = curl_init($uploadUrl);
        if ($ch === false) throw new RuntimeException('Не удалось инициализировать загрузку файла.');
        $fh = fopen($tmpPath, 'rb');
        $curlFile = new \CURLFile($tmpPath, $mime ?: 'application/octet-stream', $name ?: basename($tmpPath));
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 30,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_HTTPHEADER => ['Authorization: '.Settings::token()],
            CURLOPT_POSTFIELDS => ['data' => $curlFile],
        ]);
        $raw = curl_exec($ch);
        $errno = curl_errno($ch); $error = curl_error($ch); $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch); if (is_resource($fh)) fclose($fh);
        if ($errno || $http < 200 || $http >= 300) throw new RuntimeException('MAX upload HTTP '.$http.': '.($error ?: (string)$raw));
        $uploaded = json_decode((string)$raw, true);
        if (!is_array($uploaded)) throw new RuntimeException('MAX вернул некорректный ответ загрузки.');
        $token = (string)($uploaded['token'] ?? '');
        if ($token === '' && isset($uploaded['photos']) && is_array($uploaded['photos'])) { $photoSet = reset($uploaded['photos']); if (is_array($photoSet)) $token = (string)($photoSet['token'] ?? ''); }
        if ($token === '' && isset($data['token'])) $token = (string)$data['token'];
        if ($token === '') throw new RuntimeException('MAX не вернул токен файла.');
        return ['token'=>$token,'upload'=>$uploaded,'init'=>$data];
    }

    public function sendAttachment(string $chatId, string $text, string $type, string $token, ?string $replyToMid = null): array
    {
        $body = ['text'=>$text, 'format'=>'markdown', 'attachments'=>[['type'=>$type,'payload'=>['token'=>$token]]]];
        if ($replyToMid) $body['link']=['type'=>'reply','mid'=>$replyToMid];
        return $this->request('POST','/messages', $body, ['chat_id'=>(int)$chatId]);
    }

    public function sendMessage(string $chatId, string $text, ?string $replyToMid = null): array
    {
        // MAX API expects chat_id as a QUERY parameter, not inside the JSON body.
        // Putting it into the body makes MAX see no recipient and return
        // {"code":"proto.payload","message":"Unknown recipient"}.
        $body = ['text'=>$text, 'format'=>'markdown'];
        if ($replyToMid) $body['link']=['type'=>'reply','mid'=>$replyToMid];
        return $this->request('POST','/messages', $body, ['chat_id'=>(int)$chatId]);
    }
    public function subscribe(string $url, string $secret): array
    {
        return $this->request('POST','/subscriptions',['url'=>$url,'update_types'=>['message_created','bot_added','bot_removed','bot_admin_permissions_changed'],'secret'=>$secret]);
    }
    public function subscriptions(): array { return $this->request('GET','/subscriptions'); }
}
