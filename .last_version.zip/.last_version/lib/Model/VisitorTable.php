<?php
namespace Resurs\Kdigitals\Model;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\ORM\Fields\TextField;
use Bitrix\Main\ORM\Fields\DatetimeField;
use Bitrix\Main\Type\DateTime;
class VisitorTable extends DataManager
{
    public static function getTableName(): string { return 'kdigitals_kdigitals_visitor'; }
    public static function getMap(): array { return [
        new IntegerField('ID',['primary'=>true,'autocomplete'=>true]), new StringField('SITE_ID',['required'=>true,'size'=>2]), new StringField('VISITOR_KEY',['required'=>true,'size'=>64]), new StringField('VISITOR_NAME',['size'=>120]), new StringField('SESSION_ID',['size'=>128]), new StringField('IP',['size'=>45]), new StringField('IP_HASH',['size'=>128]), new TextField('USER_AGENT'), new StringField('FIRST_PAGE',['size'=>2048]), new StringField('LAST_PAGE',['size'=>2048]), new DatetimeField('CREATED_AT',['default_value'=>fn()=>new DateTime()]), new DatetimeField('UPDATED_AT',['default_value'=>fn()=>new DateTime()]),
    ]; }
}
