<?php
namespace Resurs\Kdigitals\Model;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\ORM\Fields\DatetimeField;
use Bitrix\Main\Type\DateTime;
class ChatTable extends DataManager
{
    public static function getTableName(): string { return 'kdigitals_kdigitals_chat'; }
    public static function getMap(): array { return [
        new IntegerField('ID',['primary'=>true,'autocomplete'=>true]), new StringField('MAX_CHAT_ID',['required'=>true,'size'=>64]), new StringField('TYPE',['size'=>20]), new StringField('TITLE',['size'=>255]), new StringField('IS_CHANNEL',['size'=>1]), new StringField('ACTIVE',['size'=>1]), new DatetimeField('CREATED_AT',['default_value'=>fn()=>new DateTime()]), new DatetimeField('UPDATED_AT',['default_value'=>fn()=>new DateTime()]),
    ]; }
}
