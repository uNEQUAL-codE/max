<?php
namespace Resurs\Kdigitals\Model;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\ORM\Fields\TextField;
use Bitrix\Main\ORM\Fields\DatetimeField;
use Bitrix\Main\Type\DateTime;
class MessageTable extends DataManager
{
    public static function getTableName(): string { return 'kdigitals_kdigitals_message'; }
    public static function getMap(): array { return [
        new IntegerField('ID',['primary'=>true,'autocomplete'=>true]), new IntegerField('CONVERSATION_ID',['required'=>true]), new StringField('DIRECTION',['required'=>true,'size'=>16]), new StringField('SENDER_TYPE',['required'=>true,'size'=>16]), new TextField('MESSAGE_TEXT'), new StringField('MAX_MESSAGE_ID',['size'=>128]), new StringField('CLIENT_MESSAGE_ID',['size'=>64]), new TextField('RAW_JSON'), new DatetimeField('CREATED_AT',['default_value'=>fn()=>new DateTime()]),
    ]; }
}
