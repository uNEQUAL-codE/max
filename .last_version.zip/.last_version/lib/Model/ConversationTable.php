<?php
namespace Resurs\Kdigitals\Model;
use Bitrix\Main\ORM\Data\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\ORM\Fields\DatetimeField;
use Bitrix\Main\Type\DateTime;
class ConversationTable extends DataManager
{
    public static function getTableName(): string { return 'kdigitals_kdigitals_conversation'; }
    public static function getMap(): array { return [
        new IntegerField('ID',['primary'=>true,'autocomplete'=>true]), new StringField('SITE_ID',['required'=>true,'size'=>2]), new IntegerField('VISITOR_ID',['required'=>true]), new StringField('MAX_CHAT_ID',['required'=>true,'size'=>64]), new StringField('STATUS',['required'=>true,'size'=>20]), new StringField('PAGE_URL',['size'=>2048]), new DatetimeField('CREATED_AT',['default_value'=>fn()=>new DateTime()]), new DatetimeField('UPDATED_AT',['default_value'=>fn()=>new DateTime()]), new DatetimeField('CLOSED_AT'),
    ]; }
}
