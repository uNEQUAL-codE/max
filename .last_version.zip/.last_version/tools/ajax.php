<?php
ob_start();
$__km_json_done=false;
register_shutdown_function(function(){
    global $__km_json_done;
    if ($__km_json_done) return;
    $e=error_get_last();
    if ($e && in_array($e['type'], [E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR], true)) {
        while (ob_get_level()>0) { @ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false,'error'=>'Ошибка сервера при обработке запроса.'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }
});
function kmJson(array $data,int $status=200): void {
    global $__km_json_done;
    $__km_json_done=true;
    while (ob_get_level()>0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php';
use Bitrix\Main\Context;
use Bitrix\Main\Loader;
use Resurs\Kdigitals\Service\ChatService;
use Resurs\Kdigitals\Service\Settings;
if(!Loader::includeModule('kdigitals.max')){kmJson(['ok'=>false,'error'=>'module'],500);exit;}
$r=Context::getCurrent()->getRequest();
$action=(string)($r->getPost('action') ?: $r->getQuery('action'));
// Reject cross-site state-changing requests. The public widget is same-origin;
// a foreign Origin/Sec-Fetch-Site must not create conversations or send files.
if (in_array($action, ['open','send','messages'], true)) {
    $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
    $fetchSite = strtolower((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? ''));
    $requestHost = strtolower((string)$r->getHttpHost());
    if ($fetchSite === 'cross-site') { kmJson(['ok'=>false,'error'=>'forbidden'],403); exit; }
    if ($origin !== '') {
        $originHost = strtolower((string)parse_url($origin, PHP_URL_HOST));
        $originScheme = strtolower((string)parse_url($origin, PHP_URL_SCHEME));
        $requestScheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        if (!in_array($originScheme, ['http','https'], true) || $originHost === '' ||
            $originHost !== preg_replace('/:\\d+$/', '', $requestHost) ||
            $originScheme !== $requestScheme) {
            kmJson(['ok'=>false,'error'=>'forbidden'],403); exit;
        }
    }
}

if($action==='config'){
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    $cfg=[
        'title'=>Settings::widgetTitle(),
        'subtitle'=>Settings::get('subtitle','Мы отвечаем через MAX'),
        'greeting'=>Settings::greeting(),
        'buttonText'=>Settings::get('button_text','Чат'),
        'position'=>Settings::get('position','right'),
        'color'=>Settings::get('color','#471AFF'),
        'headerColor2'=>Settings::get('header_color_2','#00BFFF'),
        'buttonSize'=>(int)Settings::get('button_size','66'),
        'borderRadius'=>(int)Settings::get('border_radius','22'),
        'offsetX'=>(int)Settings::get('offset_x','24'),
        'offsetY'=>(int)Settings::get('offset_y','24'),
        'avatarUrl'=>Settings::get('avatar_url','/bitrix/js/kdigitals.max/max-icon.svg'),
        'buttonIconUrl'=>Settings::get('button_icon_url','/bitrix/js/kdigitals.max/max-icon.svg'),
        'avatarShape'=>Settings::get('avatar_shape','square')==='circle'?'circle':'square',
        'avatarZoom'=>max(100,min(200,(int)Settings::get('avatar_zoom','100'))),
        'avatarX'=>max(0,min(100,(int)Settings::get('avatar_x','50'))),
        'avatarY'=>max(0,min(100,(int)Settings::get('avatar_y','50'))),
        'buttonIconShape'=>Settings::get('button_icon_shape','circle')==='square'?'square':'circle',
        'buttonIconZoom'=>max(100,min(200,(int)Settings::get('button_icon_zoom','100'))),
        'buttonIconX'=>max(0,min(100,(int)Settings::get('button_icon_x','50'))),
        'buttonIconY'=>max(0,min(100,(int)Settings::get('button_icon_y','50'))),
        'managerName'=>Settings::managerName(),
        'workStartTime'=>Settings::get('work_start_time','09:00'),
        'workEndTime'=>Settings::get('work_end_time','17:00'),
    ];
    kmJson(['ok'=>true,'config'=>$cfg]);exit;
}
try{
 if($action==='open'){ $key=preg_replace('/[^a-zA-Z0-9_-]/','',(string)$r->getPost('visitor_key')); if($key==='')throw new RuntimeException('visitor_key'); kmJson(['ok'=>true,'conversation'=>ChatService::open($key,(string)$r->getPost('page_url'))]);exit; }
 if($action==='send'){ $id=(int)$r->getPost('conversation_id');$text=trim((string)$r->getPost('text'));$visitorName='Пользователь';$clientId=(string)$r->getPost('client_message_id');$visitorKey=preg_replace('/[^a-zA-Z0-9_-]/','',(string)$r->getPost('visitor_key'));$file=$_FILES['file']??null;
    if($visitorKey===''){kmJson(['ok'=>false,'error'=>'forbidden'],403);exit;}
    kmJson(['ok'=>true,'result'=>ChatService::send($id,$text,$clientId,$file,$visitorName,$visitorKey)]);exit; }
 if($action==='messages'){
    $id=(int)$r->getPost('conversation_id');$after=(int)$r->getPost('after_id');
    $visitorKey=preg_replace('/[^a-zA-Z0-9_-]/','',(string)$r->getPost('visitor_key'));
    if($visitorKey==='' || $after<0){kmJson(['ok'=>false,'error'=>'forbidden'],403);exit;}
    // Fast, short AJAX poll. MAX delivery remains Webhook-based; the browser
    // only checks the local DB and never keeps a PHP request open.
    $messages=ChatService::messages($id,$after,$visitorKey);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    kmJson(['ok'=>true,'messages'=>$messages]);exit;
 }
 throw new RuntimeException('Неизвестное действие');
}catch(Throwable $e){kmJson(['ok'=>false,'error'=>$e->getMessage()],400);}
