<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php';
use Bitrix\Main\Loader;
use Resurs\Kdigitals\Service\Settings;
use Resurs\Kdigitals\Service\WebhookService;
header('Content-Type: application/json; charset=utf-8');
if(!Loader::includeModule('kdigitals.max')){http_response_code(500);echo json_encode(['ok'=>false]);exit;}
$secret=Settings::webhookSecret();$provided=(string)($_SERVER['HTTP_X_MAX_BOT_API_SECRET']??'');
// Fail closed: never accept webhook requests until a non-empty secret is configured.
if($secret==='' || $provided==='' || !hash_equals($secret,$provided)){http_response_code(403);echo json_encode(['ok'=>false]);exit;}
try{WebhookService::handle(json_decode(file_get_contents('php://input'),true)?:[]);echo json_encode(['ok'=>true]);}catch(Throwable $e){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'internal']);}
