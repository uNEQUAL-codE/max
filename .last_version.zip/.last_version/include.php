<?php
use Bitrix\Main\Loader;
Loader::registerAutoLoadClasses('kdigitals.max', [
    'Resurs\\Kdigitals\\Api\\MaxApi' => 'lib/Api/MaxApi.php',
    'Resurs\\Kdigitals\\Model\\ConversationTable' => 'lib/Model/ConversationTable.php',
    'Resurs\\Kdigitals\\Model\\MessageTable' => 'lib/Model/MessageTable.php',
    'Resurs\\Kdigitals\\Model\\VisitorTable' => 'lib/Model/VisitorTable.php',
    'Resurs\\Kdigitals\\Model\\ChatTable' => 'lib/Model/ChatTable.php',
    'Resurs\\Kdigitals\\Service\\Settings' => 'lib/Service/Settings.php',
    'Resurs\\Kdigitals\\Service\\ChatService' => 'lib/Service/ChatService.php',
    'Resurs\\Kdigitals\\Service\\WebhookService' => 'lib/Service/WebhookService.php',
    'Resurs\\Kdigitals\\Service\\Widget' => 'lib/Service/Widget.php',
    'Resurs\\Kdigitals\\Service\\EventHandler' => 'lib/Service/EventHandler.php',
    'Resurs\\Kdigitals\\Service\\AdminMenu' => 'lib/Service/AdminMenu.php',
]);
?>
