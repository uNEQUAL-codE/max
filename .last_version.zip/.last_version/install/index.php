<?php
use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\ModuleManager;

Loc::loadMessages(__FILE__);

class kdigitals_max extends CModule
{
    public $MODULE_ID = 'kdigitals.max';
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $PARTNER_NAME = 'ИП Камчатный Д.А.';
    public $PARTNER_URI = '';

    public function __construct()
{
    $this->MODULE_ID = 'kdigitals.max';
    $this->PARTNER_NAME = 'ИП Камчатный Д.А.';
    $this->PARTNER_URI = 'http://demo.kdigitals.ru';

    $this->MODULE_NAME = Loc::getMessage('KDIGITALS_KDIGITALS_MODULE_NAME');
    $this->MODULE_DESCRIPTION = Loc::getMessage('KDIGITALS_KDIGITALS_MODULE_DESC');

    include __DIR__ . '/version.php';
    $this->MODULE_VERSION = $arModuleVersion['VERSION'];
    $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
}

    public function DoInstall()
    {
        global $APPLICATION;
        if (!CheckVersion(ModuleManager::getVersion('main'), '20.0.0')) {
            $APPLICATION->ThrowException('Требуется 1С-Битрикс 20.0.0 или новее.');
            return false;
        }
        ModuleManager::registerModule($this->MODULE_ID);
        $this->installDb();
        $this->installEvents();
        $this->installFiles();

        // При повторной установке после удаления с сохранением данных
        // не перезаписываем ранее сохранённые настройки значениями по умолчанию.
        $defaults = [
            'enabled' => 'Y',
            'position' => 'right',
            'button_text' => 'Чат',
            'title' => 'Онлайн-консультант',
            'greeting' => 'Здравствуйте! Напишите нам, и мы ответим в MAX.',
            'subtitle' => 'Мы отвечаем через MAX',
            'color' => '#471AFF',
            'header_color_2' => '#00BFFF',
            'button_size' => '66',
            'border_radius' => '22',
            'offset_x' => '24',
            'offset_y' => '24',
            'avatar_url' => '/bitrix/js/kdigitals.max/max-icon.svg',
            'manager_name' => 'Администратор',
            'ip_hash_salt' => bin2hex(random_bytes(16)),
            // Generate a unique webhook secret at install time; webhook endpoint fails closed if absent.
            'webhook_secret' => bin2hex(random_bytes(32)),
        ];
        foreach ($defaults as $name => $value) {
            if (Option::get($this->MODULE_ID, $name, '') === '') {
                Option::set($this->MODULE_ID, $name, $value);
            }
        }
        $APPLICATION->IncludeAdminFile($this->MODULE_NAME, __DIR__ . '/step.php');
    }

    public function DoUninstall()
    {
        global $APPLICATION, $USER;
        if (is_object($USER) && !$USER->IsAdmin()) {
            return false;
        }
        if (!check_bitrix_sessid()) {
            return false;
        }

        $step = (int)($_REQUEST['step'] ?? 1);
        if ($step < 2) {
            $APPLICATION->IncludeAdminFile($this->MODULE_NAME, __DIR__ . '/uninstall_step1.php');
            return true;
        }

        $savedata = (($_REQUEST['savedata'] ?? 'Y') === 'Y');
        $savedOptions = [];

        if ($savedata) {
            $db = Application::getConnection();
            $sqlHelper = $db->getSqlHelper();
            $moduleId = $sqlHelper->forSql($this->MODULE_ID);
            $res = $db->query("SELECT NAME, VALUE, SITE_ID FROM b_option WHERE MODULE_ID = '{$moduleId}'");
            while ($row = $res->fetch()) {
                $savedOptions[] = $row;
            }
        }

        $this->uninstallEvents();
        if (!$savedata) {
            // Полное удаление данных как при «Сбросить все настройки»:
            // очищаем параметры модуля, кеши и таблицы истории.
            Option::delete($this->MODULE_ID);
            if (class_exists('\\Resurs\\Kdigitals\\Service\\Settings')) {
                \Resurs\Kdigitals\Service\Settings::clearPublicCache();
            } else {
                try { if (function_exists('BXClearCache')) { BXClearCache(true); } } catch (\Throwable $e) {}
                try { if (class_exists('\\Bitrix\\Main\\Data\\StaticHtmlCache')) { \Bitrix\Main\Data\StaticHtmlCache::getInstance()->deleteAll(); } } catch (\Throwable $e) {}
            }
            $this->uninstallDb();
        }
        $this->uninstallFiles();
        ModuleManager::unRegisterModule($this->MODULE_ID);

        // UnRegisterModule удаляет настройки модуля. Если администратор
        // выбрал сохранение, возвращаем их обратно после снятия регистрации.
        if ($savedata && $savedOptions) {
            foreach ($savedOptions as $row) {
                Option::set(
                    $this->MODULE_ID,
                    (string)$row['NAME'],
                    (string)$row['VALUE'],
                    $row['SITE_ID'] !== null && $row['SITE_ID'] !== '' ? (string)$row['SITE_ID'] : false
                );
            }
        }

        $APPLICATION->IncludeAdminFile($this->MODULE_NAME, __DIR__ . '/uninstall_step2.php');
        return true;
    }

    public function installFiles(): void
    {
        $root = Application::getDocumentRoot();
        CopyDirFiles(__DIR__ . '/../admin', $root . '/bitrix/admin', true, true);
        CopyDirFiles(__DIR__ . '/../tools', $root . '/bitrix/tools/kdigitals.max', true, true);
        CheckDirPath($root . '/bitrix/js/kdigitals.max/');
        CopyDirFiles(__DIR__ . '/../assets/js', $root . '/bitrix/js/kdigitals.max', true, true);
        CopyDirFiles(__DIR__ . '/../assets/css', $root . '/bitrix/js/kdigitals.max', true, true);
        CheckDirPath($root . '/bitrix/js/kdigitals.max/');
        CopyDirFiles(__DIR__ . '/../assets/img', $root . '/bitrix/js/kdigitals.max', true, true);
        // Bitrix loads module admin icon styles from the theme directory.
        // Keep the icon files beside the CSS so the menu icon works reliably.
        CopyDirFiles(__DIR__ . '/themes', $root . '/bitrix/themes', true, true);
        // Backward compatibility for installations upgraded from 0.3.x.
        CopyDirFiles(__DIR__ . '/../assets/admin', $root . '/bitrix/themes/.default', true, true);
    }

    public function uninstallFiles(): void
    {
        $root = Application::getDocumentRoot();
        @unlink($root . '/bitrix/admin/kdigitals_kdigitals.php');
        @unlink($root . '/bitrix/admin/kdigitals_kdigitals_settings.php');
        @unlink($root . '/bitrix/admin/kdigitals_kdigitals_cleanup.php');

        DeleteDirFilesEx('/bitrix/tools/kdigitals.max');
        DeleteDirFilesEx('/bitrix/js/kdigitals.max');
        @unlink($root . '/bitrix/themes/.default/kdigitals_kdigitals.css');
        DeleteDirFilesEx('/bitrix/themes/.default/icons/kdigitals_kdigitals');
    }

    public function installEvents(): void
    {
        RegisterModuleDependences('main', 'OnBuildGlobalMenu', $this->MODULE_ID, '\\Resurs\\Kdigitals\\Service\\AdminMenu', 'onBuildGlobalMenu');
        RegisterModuleDependences('main', 'OnEndBufferContent', $this->MODULE_ID, '\\Resurs\\Kdigitals\\Service\\EventHandler', 'onEndBufferContent', 100, __DIR__ . '/../lib/Service/EventHandler.php');
    }

    public function uninstallEvents(): void
    {
        UnRegisterModuleDependences('main', 'OnBuildGlobalMenu', $this->MODULE_ID, '\\Resurs\\Kdigitals\\Service\\AdminMenu', 'onBuildGlobalMenu');
        UnRegisterModuleDependences('main', 'OnEndBufferContent', $this->MODULE_ID, '\\Resurs\\Kdigitals\\Service\\EventHandler', 'onEndBufferContent', 100, __DIR__ . '/../lib/Service/EventHandler.php');
    }

    public function installDb(): void
    {
        $db = Application::getConnection();
        $queries = [
            "CREATE TABLE IF NOT EXISTS kdigitals_kdigitals_visitor (ID int unsigned NOT NULL AUTO_INCREMENT, SITE_ID varchar(2) NOT NULL, VISITOR_KEY varchar(64) NOT NULL, SESSION_ID varchar(128) DEFAULT NULL, VISITOR_NAME varchar(120) DEFAULT NULL, IP varchar(45) DEFAULT NULL, IP_HASH varchar(128) DEFAULT NULL, USER_AGENT text, FIRST_PAGE varchar(2048) DEFAULT NULL, LAST_PAGE varchar(2048) DEFAULT NULL, CREATED_AT datetime NOT NULL, UPDATED_AT datetime NOT NULL, PRIMARY KEY(ID), UNIQUE KEY UX_VISITOR(SITE_ID,VISITOR_KEY), KEY IX_UPDATED(UPDATED_AT)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS kdigitals_kdigitals_conversation (ID int unsigned NOT NULL AUTO_INCREMENT, SITE_ID varchar(2) NOT NULL, VISITOR_ID int unsigned NOT NULL, MAX_CHAT_ID varchar(64) NOT NULL, STATUS varchar(20) NOT NULL DEFAULT 'OPEN', PAGE_URL varchar(2048) DEFAULT NULL, CREATED_AT datetime NOT NULL, UPDATED_AT datetime NOT NULL, CLOSED_AT datetime DEFAULT NULL, PRIMARY KEY(ID), KEY IX_VISITOR(VISITOR_ID), KEY IX_STATUS(STATUS), KEY IX_MAX_CHAT(MAX_CHAT_ID), KEY IX_UPDATED(UPDATED_AT)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS kdigitals_kdigitals_message (ID bigint unsigned NOT NULL AUTO_INCREMENT, CONVERSATION_ID int unsigned NOT NULL, DIRECTION varchar(16) NOT NULL, SENDER_TYPE varchar(16) NOT NULL, MESSAGE_TEXT text, MAX_MESSAGE_ID varchar(128) DEFAULT NULL, CLIENT_MESSAGE_ID varchar(64) DEFAULT NULL, RAW_JSON longtext, CREATED_AT datetime NOT NULL, PRIMARY KEY(ID), UNIQUE KEY UX_MAXID(MAX_MESSAGE_ID), KEY IX_CLIENT_CONV(CONVERSATION_ID,CLIENT_MESSAGE_ID), KEY IX_CONVERSATION(CONVERSATION_ID,ID)) ENGINE=InnoDB",
            "CREATE TABLE IF NOT EXISTS kdigitals_kdigitals_chat (ID int unsigned NOT NULL AUTO_INCREMENT, MAX_CHAT_ID varchar(64) NOT NULL, TYPE varchar(20) DEFAULT NULL, TITLE varchar(255) DEFAULT NULL, IS_CHANNEL char(1) NOT NULL DEFAULT 'N', ACTIVE char(1) NOT NULL DEFAULT 'Y', CREATED_AT datetime NOT NULL, UPDATED_AT datetime NOT NULL, PRIMARY KEY(ID), UNIQUE KEY UX_CHAT(MAX_CHAT_ID)) ENGINE=InnoDB",
        ];
        foreach ($queries as $sql) { $db->queryExecute($sql); }
        // Upgrade an existing 0.3.x installation without dropping chat history.
        try { $db->queryExecute("ALTER TABLE kdigitals_kdigitals_visitor ADD COLUMN VISITOR_NAME varchar(120) DEFAULT NULL"); } catch (\Throwable $e) {}
        try { $db->queryExecute("ALTER TABLE kdigitals_kdigitals_message ADD COLUMN CLIENT_MESSAGE_ID varchar(64) DEFAULT NULL"); } catch (\Throwable $e) {}
        try { $db->queryExecute("ALTER TABLE kdigitals_kdigitals_message ADD UNIQUE KEY UX_CLIENTID(CLIENT_MESSAGE_ID)"); } catch (\Throwable $e) {}
    }

    public function uninstallDb(): void
    {
        $db = Application::getConnection();
        foreach (['kdigitals_kdigitals_message','kdigitals_kdigitals_conversation','kdigitals_kdigitals_visitor','kdigitals_kdigitals_chat'] as $table) {
            $db->queryExecute('DROP TABLE IF EXISTS ' . $table);
        }
    }
}
