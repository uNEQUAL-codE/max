<?php
$arModuleVersion = [
    'VERSION' => '0.4.38',
    'VERSION_DATE' => '2026-10-13 21:20:00',
];
