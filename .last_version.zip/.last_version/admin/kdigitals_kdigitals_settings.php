<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php';
use Bitrix\Main\Loader;
use Resurs\Kdigitals\Service\Settings;
use Resurs\Kdigitals\Api\MaxApi;
use Resurs\Kdigitals\Model\ChatTable;

if (!Loader::includeModule('kdigitals.max')) {
    ShowError('Модуль не установлен.');
    require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';
    return;
}

// Защита административных настроек: только полный администратор
// или пользователь с правом записи в модуль.
global $USER, $APPLICATION;
if ((!is_object($USER) || !$USER->IsAdmin())
    && $APPLICATION->GetGroupRight('kdigitals.max') < 'W') {
    $APPLICATION->AuthForm(GetMessage('ACCESS_DENIED'));
    exit;
}

$APPLICATION->SetTitle('Онлайн-чат МАКС');
$saved = false;
$testResult = '';
$activeTab = (string)($_GET['tab'] ?? $_POST['tab'] ?? 'dashboard');
$allowedTabs = ['dashboard', 'connection', 'widget', 'advanced'];
if (!in_array($activeTab, $allowedTabs, true)) { $activeTab = 'dashboard'; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && check_bitrix_sessid()) {
    $action = (string)($_POST['action'] ?? 'save');
    $activeTab = (string)($_POST['tab'] ?? 'dashboard');
    if (!in_array($activeTab, $allowedTabs, true)) { $activeTab = 'dashboard'; }

    if ($action === 'reset_all') {
        Settings::resetAll();
        $saved = true;
        $testResult = '<div class="rmc-admin-notice success">✓ Все настройки сброшены: параметры виджета и подключения MAX очищены. История чатов и сообщения не удалены.</div>';
        $activeTab = 'advanced';
    }

    if ($action === 'save') {
        // IMPORTANT: save only fields from the current form/tab.
        // The previous implementation wrote empty strings for fields that
        // were not present in the form, so saving the widget reset MAX
        // connection settings. Each tab is now completely independent.
        $tabFields = [
            'connection' => ['access_token', 'max_chat_id', 'webhook_secret'],
            'widget' => [
                'title','greeting','button_text','position','color',
                'header_color_2','button_size','border_radius','offset_x','offset_y','avatar_url','manager_name','button_icon_url','avatar_shape','avatar_zoom','avatar_x','avatar_y','button_icon_shape','button_icon_zoom','button_icon_x','button_icon_y','work_start_time','work_end_time'
            ],
            'advanced' => ['enabled'],
        ];
        $fields = $tabFields[$activeTab] ?? [];

        // Optional widget avatar upload. It is stored in /upload so the
        // public widget can display it without exposing admin paths.
        if ($activeTab === 'widget' && isset($_FILES['avatar_file']) && is_array($_FILES['avatar_file']) && (int)$_FILES['avatar_file']['error'] === UPLOAD_ERR_OK) {
            $tmp = (string)$_FILES['avatar_file']['tmp_name'];
            $size = (int)$_FILES['avatar_file']['size'];
            $mime = '';
            if (function_exists('finfo_open')) {
                $fi = finfo_open(FILEINFO_MIME_TYPE);
                $mime = $fi ? (string)finfo_file($fi, $tmp) : '';
                if ($fi) finfo_close($fi);
            }
            $allowed = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'image/gif' => 'gif',
            ];
            if ($size > 5 * 1024 * 1024) {
                $testResult = '<div class="rmc-admin-notice error">✕ Аватар слишком большой. Максимум 5 МБ.</div>';
            } elseif (!isset($allowed[$mime])) {
                $testResult = '<div class="rmc-admin-notice error">✕ Для аватара разрешены JPG, PNG, WEBP или GIF.</div>';
            } else {
                $uploadDir = $_SERVER['DOCUMENT_ROOT'].'/upload/kdigitals.max';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                $fileName = 'avatar.'. $allowed[$mime];
                $dest = $uploadDir.'/'.$fileName;
                if (@move_uploaded_file($tmp, $dest)) {
                    Settings::set('avatar_url', '/upload/kdigitals.max/'.$fileName.'?v='.time());
                } else {
                    $testResult = '<div class="rmc-admin-notice error">✕ Не удалось сохранить аватар.</div>';
                }
            }
        }
        // Optional opening-button icon upload. Stored separately from the header avatar.
        if ($activeTab === 'widget' && isset($_FILES['button_icon_file']) && is_array($_FILES['button_icon_file']) && (int)$_FILES['button_icon_file']['error'] === UPLOAD_ERR_OK) {
            $tmp = (string)$_FILES['button_icon_file']['tmp_name'];
            $size = (int)$_FILES['button_icon_file']['size'];
            $mime = '';
            if (function_exists('finfo_open')) {
                $fi = finfo_open(FILEINFO_MIME_TYPE);
                $mime = $fi ? (string)finfo_file($fi, $tmp) : '';
                if ($fi) finfo_close($fi);
            }
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
            if ($size > 5 * 1024 * 1024) {
                $testResult = '<div class="rmc-admin-notice error">✕ Иконка кнопки слишком большая. Максимум 5 МБ.</div>';
            } elseif (!isset($allowed[$mime])) {
                $testResult = '<div class="rmc-admin-notice error">✕ Для иконки разрешены JPG, PNG, WEBP, GIF или SVG.</div>';
            } else {
                $uploadDir = $_SERVER['DOCUMENT_ROOT'].'/upload/kdigitals.max';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                $fileName = 'button-icon.'. $allowed[$mime];
                $dest = $uploadDir.'/'.$fileName;
                if (@move_uploaded_file($tmp, $dest)) {
                    Settings::set('button_icon_url', '/upload/kdigitals.max/'.$fileName.'?v='.time());
                } else {
                    $testResult = '<div class="rmc-admin-notice error">✕ Не удалось сохранить иконку кнопки.</div>';
                }
            }
        }

        // Server-side allow-list validation: client-side pattern attributes are not security controls.
        $hexFields = ['color', 'header_color_2'];
        $enumFields = [
            'position' => ['left', 'right'],
            'avatar_shape' => ['circle', 'square'],
            'button_icon_shape' => ['circle', 'square'],
        ];
        $intRanges = [
            'button_size' => [52, 82], 'border_radius' => [12, 30],
            'offset_x' => [8, 80], 'offset_y' => [8, 80],
            'avatar_zoom' => [100, 200], 'avatar_x' => [0, 100], 'avatar_y' => [0, 100],
            'button_icon_zoom' => [100, 200], 'button_icon_x' => [0, 100], 'button_icon_y' => [0, 100],
        ];
        $maxLengths = [
            'access_token' => 4096, 'max_chat_id' => 255, 'webhook_secret' => 255,
            'title' => 120, 'greeting' => 1000, 'button_text' => 40,
            'avatar_url' => 500, 'button_icon_url' => 500, 'manager_name' => 100,
            'work_start_time' => 5, 'work_end_time' => 5,
        ];
        foreach ($fields as $k) {
            if ($k === 'enabled') {
                Settings::set($k, isset($_POST[$k]) ? 'Y' : 'N');
                continue;
            }
            if (!array_key_exists($k, $_POST) || !is_scalar($_POST[$k])) { continue; }
            $v = trim((string)$_POST[$k]);
            if (in_array($k, $hexFields, true)) {
                if (!preg_match('/^#[0-9a-fA-F]{6}$/D', $v)) { continue; }
                $v = strtoupper($v);
            } elseif (isset($enumFields[$k])) {
                if (!in_array($v, $enumFields[$k], true)) { continue; }
            } elseif (isset($intRanges[$k])) {
                if (!preg_match('/^-?\d+$/D', $v)) { continue; }
                [$min, $max] = $intRanges[$k];
                $v = (string)max($min, min($max, (int)$v));
            } elseif (in_array($k, ['work_start_time', 'work_end_time'], true)) {
                if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D', $v)) { continue; }
            } elseif (in_array($k, ['avatar_url', 'button_icon_url'], true)) {
                // Only accept same-site absolute paths; never store executable schemes or external URLs.
                if ($v !== '' && (!preg_match('~^/(?:upload/kdigitals\.kdigitals/[A-Za-z0-9._?=&%-]+|bitrix/js/kdigitals\.kdigitals/[A-Za-z0-9._-]+)$~D', $v))) { continue; }
            }
            if (isset($maxLengths[$k])) { $v = mb_substr($v, 0, $maxLengths[$k], 'UTF-8'); }
            // Strip control characters from user-facing text and credentials, preserving ordinary Unicode.
            if (in_array($k, ['title','greeting','button_text','manager_name'], true)) {
                $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $v);
            }
            Settings::set($k, $v);
        }

        // The widget is injected into the public HTML by OnEndBufferContent.
        // If Bitrix serves a cached/Composite page, that event is not executed
        // at all, so the visitor can keep seeing the previous configuration.
        // Clear public caches after every settings save.
        if (in_array($activeTab, ['widget', 'advanced'], true)) {
            Settings::clearPublicCache();
        }

        $saved = true;
        $testResult = '<div class="rmc-admin-notice success">✓ Настройки сохранены. Виджет на сайте получает актуальную конфигурацию автоматически</div>';
    }

    if ($action === 'test') {
        try {
            $me = (new MaxApi())->me();
            $name = (string)($me['name'] ?? $me['username'] ?? 'MAX Bot');
            $testResult = '<div class="rmc-admin-notice success">✓ MAX API подключен. Бот: <b>'.htmlspecialcharsbx($name).'</b></div>';
        } catch (Throwable $e) {
            $testResult = '<div class="rmc-admin-notice error">✕ Ошибка MAX API: '.htmlspecialcharsbx($e->getMessage()).'</div>';
        }
    }

    if ($action === 'webhook') {
        try {
            $secret = Settings::webhookSecret();
            if ($secret === '') {
                $secret = bin2hex(random_bytes(12));
                Settings::set('webhook_secret', $secret);
            }
            $siteHost = trim((string)\Bitrix\Main\Config\Option::get('main', 'server_name', ''));
            $trustedHosts = array_filter(array_map('trim', explode("\n", (string)\Bitrix\Main\Config\Option::get('main', 'trusted_hosts', ''))));
            if ($siteHost === '' || !preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*$/i', $siteHost)
                || ($trustedHosts && !in_array($siteHost, $trustedHosts, true))) {
                throw new \RuntimeException('Укажите корректный основной домен в настройках сайта (server_name), прежде чем подключать Webhook.');
            }
            $url = 'https://'.$siteHost.'/bitrix/tools/kdigitals.max/webhook.php';
            (new MaxApi())->subscribe($url, $secret);
            $testResult = '<div class="rmc-admin-notice success">✓ Webhook подключён</div>';
        } catch (Throwable $e) {
            $testResult = '<div class="rmc-admin-notice error">✕ Ошибка Webhook: '.htmlspecialcharsbx($e->getMessage()).'</div>';
        }
    }
}

$token = Settings::get('access_token');
$chatId = Settings::chatId();
$secret = Settings::webhookSecret();
$title = Settings::widgetTitle();
$subtitle = Settings::get('subtitle', 'Мы отвечаем через MAX');
$greeting = Settings::greeting();
$buttonText = Settings::get('button_text', 'Чат');
$position = Settings::get('position', 'right');
$color = (string)Settings::get('color', '#471AFF');
if (!preg_match('/^#[0-9a-fA-F]{6}$/D', $color)) { $color = '#471AFF'; }
$headerColor2 = (string)Settings::get('header_color_2', '#00BFFF');
if (!preg_match('/^#[0-9a-fA-F]{6}$/D', $headerColor2)) { $headerColor2 = '#00BFFF'; }
$buttonSize = (int)Settings::get('button_size', '66');
$radius = (int)Settings::get('border_radius', '22');
$offsetX = (int)Settings::get('offset_x', '24');
$offsetY = (int)Settings::get('offset_y', '24');
$avatarUrl = Settings::get('avatar_url', '/bitrix/js/kdigitals.max/max-icon.svg');
$managerName = Settings::managerName();
$workStartTime = Settings::get('work_start_time', '09:00');
$workEndTime = Settings::get('work_end_time', '17:00');
$buttonIconUrl = Settings::get('button_icon_url', '/bitrix/js/kdigitals.max/max-icon.svg');
$avatarShape = Settings::get('avatar_shape', 'square') === 'circle' ? 'circle' : 'square';
$avatarZoom = max(100, min(200, (int)Settings::get('avatar_zoom', '100')));
$avatarX = max(0, min(100, (int)Settings::get('avatar_x', '50')));
$avatarY = max(0, min(100, (int)Settings::get('avatar_y', '50')));
$buttonIconShape = Settings::get('button_icon_shape', 'square') === 'circle' ? 'circle' : 'square';
$buttonIconZoom = max(100, min(200, (int)Settings::get('button_icon_zoom', '100')));
$buttonIconX = max(0, min(100, (int)Settings::get('button_icon_x', '50')));
$buttonIconY = max(0, min(100, (int)Settings::get('button_icon_y', '50')));

$chats = ChatTable::getList(['filter'=>['=ACTIVE'=>'Y'],'order'=>['TITLE'=>'ASC']])->fetchAll();
$webhookHost = trim((string)\Bitrix\Main\Config\Option::get('main', 'server_name', ''));
$webhookUrl = ($webhookHost !== '' && preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))*$/i', $webhookHost))
    ? 'https://'.$webhookHost.'/bitrix/tools/kdigitals.max/webhook.php'
    : 'Укажите основной домен сайта в настройках Битрикс (server_name).';

require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php';
?>
<style>
.rmc-admin{--purple:#471AFF;--purple2:#6E1AFF;--cyan:#00BFFF;--ink:#0D001A;--muted:#667085;--line:#e7eaf0;--soft:#f6f7fb;max-width:1280px;margin:18px auto 40px;padding:0 14px;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif}
.rmc-hero{position:relative;overflow:hidden;border-radius:22px;padding:28px 30px;color:#fff;background:linear-gradient(135deg,#471AFF 0%,#6E1AFF 52%,#00BFFF 100%);box-shadow:0 18px 50px rgba(71,26,255,.22)}
.rmc-hero:after{content:"";position:absolute;width:280px;height:280px;border-radius:50%;right:-70px;top:-120px;background:rgba(255,255,255,.11)}
.rmc-hero h1{position:relative;z-index:1;margin:0 0 7px;font-size:30px;letter-spacing:-.5px}.rmc-hero p{position:relative;z-index:1;margin:0;opacity:.88;font-size:14px}.rmc-hero-brand{position:absolute;z-index:1;right:28px;bottom:24px;display:flex;align-items:center;gap:10px;font-weight:700}.rmc-hero-brand img{width:48px;height:48px;border-radius:15px;box-shadow:0 7px 18px rgba(0,0,0,.18)}
.rmc-tabs{display:flex;gap:8px;margin:18px 0;flex-wrap:wrap}.rmc-tab{padding:11px 15px;border-radius:12px;text-decoration:none;background:#fff;border:1px solid var(--line);color:#344054;font-weight:650;box-shadow:0 2px 7px rgba(16,24,40,.04)}.rmc-tab:hover{border-color:#c9c1ff;color:var(--purple)}.rmc-tab.active{background:#f0edff;border-color:#cfc6ff;color:#4a2cff}
.rmc-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.rmc-card{background:#fff;border:1px solid var(--line);border-radius:17px;padding:18px;box-shadow:0 5px 20px rgba(16,24,40,.05)}.rmc-card .k{font-size:12px;color:var(--muted);font-weight:600}.rmc-card .v{font-size:22px;font-weight:750;color:var(--ink);margin-top:8px}.rmc-dot{display:inline-block;width:9px;height:9px;border-radius:50%;background:#35d47a;margin-right:7px}.rmc-dot.off{background:#f04438}
.rmc-layout{display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:18px}.rmc-panel{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 5px 20px rgba(16,24,40,.05);margin-bottom:18px}.rmc-panel h2{font-size:18px;margin:0 0 5px;color:var(--ink)}.rmc-panel .desc{color:var(--muted);font-size:13px;margin-bottom:20px}.rmc-fields{display:grid;grid-template-columns:1fr 1fr;gap:16px}.rmc-field.full{grid-column:1/-1}.rmc-field label{display:block;font-weight:650;font-size:13px;color:#344054;margin-bottom:7px}.rmc-button-style-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.rmc-choice{display:block!important;padding:12px;border:1px solid #e1e4ea;border-radius:12px;background:#fafbfc}.rmc-choice span{display:block;font-weight:650;font-size:12px;color:#344054;margin-bottom:7px}.rmc-choice select{margin:0}.rmc-field input,.rmc-field textarea,.rmc-field select{width:100%;box-sizing:border-box;border:1px solid #d8dce5;border-radius:11px;padding:11px 12px;background:#fff;outline:none;font-size:14px}.rmc-field input:focus,.rmc-field textarea:focus,.rmc-field select:focus{border-color:#8b78ff;box-shadow:0 0 0 3px rgba(71,26,255,.10)}.rmc-help{font-size:12px;color:#98a2b3;margin-top:6px;line-height:1.45}.rmc-actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:18px}.rmc-primary,.rmc-secondary{border:0;border-radius:11px;padding:11px 16px;font-weight:700;cursor:pointer}.rmc-primary{color:#fff;background:linear-gradient(135deg,#471AFF,#6E1AFF);box-shadow:0 7px 18px rgba(71,26,255,.2)}.rmc-secondary{color:#344054;background:#f2f4f7}.rmc-danger{color:#b42318}.rmc-switch{display:flex;align-items:center;gap:10px}.rmc-position{display:flex;gap:10px}.rmc-position-option{display:flex!important;align-items:center;gap:8px!important;min-width:120px;padding:11px 14px;border:1px solid #d8dce5;border-radius:11px;background:#fff;cursor:pointer}.rmc-position-option:has(input:checked){border-color:#8b78ff;background:#f3f0ff;color:#471AFF}.rmc-position-option input{width:17px!important;height:17px!important;margin:0;accent-color:#471AFF}.rmc-avatar-editor{display:flex;align-items:center;gap:16px}.rmc-avatar-editor>img{width:72px;height:72px;border-radius:18px;object-fit:cover;border:1px solid #e2e5eb;box-shadow:0 5px 15px rgba(16,24,40,.08)}.rmc-switch input{width:18px;height:18px;accent-color:#471AFF}.rmc-crop-controls{margin-top:12px}.rmc-crop-controls input[type=range]{height:24px;padding:0;accent-color:#654cff}.rmc-crop-controls output{float:right;color:#654cff;font-weight:700}.rmc-upload-card>img{object-fit:cover;overflow:hidden}.rmc-preview-head img,.rmc-preview-button img{object-fit:cover;overflow:hidden}.rmc-admin-crop-frame{width:96px;height:96px;flex:0 0 96px;display:block;overflow:hidden;border-radius:14px;background:#f2f4f7;cursor:default;border:1px dashed #98a2b3}.rmc-admin-crop-frame img{pointer-events:none}.rmc-admin-crop-frame img{width:100%;height:100%;display:block;object-fit:cover}.rmc-admin-preview-crop{width:34px;height:34px;flex:0 0 34px;display:block;overflow:hidden;border-radius:11px}.rmc-admin-preview-crop img{width:100%;height:100%;display:block}.rmc-admin-preview-button-crop{width:100%;height:100%;display:block;overflow:hidden;border-radius:var(--rad)}.rmc-admin-preview-button-crop img{width:100%;height:100%;display:block}
.rmc-notice{padding:13px 15px;border-radius:12px;margin:0 0 15px}.rmc-admin-notice.success{padding:12px 14px;background:#ecfdf3;color:#027a48;border:1px solid #abefc6;border-radius:12px;margin-bottom:15px}.rmc-admin-notice.error{padding:12px 14px;background:#fef3f2;color:#b42318;border:1px solid #fecdca;border-radius:12px;margin-bottom:15px}
.rmc-preview{position:sticky;top:20px;background:linear-gradient(180deg,#f1f2f7,#e9ebf3);border:1px solid var(--line);border-radius:18px;padding:18px;min-height:590px;overflow:hidden}.rmc-preview h3{margin:0 0 5px}.rmc-preview small{color:var(--muted)}.rmc-device{position:relative;margin-top:18px;height:515px;border-radius:20px;background:linear-gradient(145deg,#fff,#f8f8fb);border:1px solid #dfe2e8;overflow:hidden;box-shadow:inset 0 0 0 5px #fff}.rmc-preview-chat{position:absolute;right:16px;bottom:78px;width:310px;height:410px;background:#fff;border-radius:18px;box-shadow:0 15px 45px rgba(13,0,26,.22);overflow:hidden}.rmc-preview-head{padding:14px;color:#fff;background:linear-gradient(135deg,var(--p1),var(--p2));display:flex;align-items:center;gap:9px}.rmc-preview-head img{width:34px;height:34px;border-radius:11px}.rmc-preview-head strong{display:block;font-size:14px}.rmc-preview-head span{font-size:11px}.rmc-preview-body{padding:12px;background:#f6f7fb;height:300px}.rmc-preview-sender{display:block;font-size:10px;font-weight:800;color:#667085;margin:0 0 4px}.rmc-bubble{display:block;width:max-content;max-width:82%;padding:9px 11px;background:#fff;border:1px solid #e6e8ed;border-radius:13px;margin-bottom:8px;font-size:12px}.rmc-bubble.out{margin-left:auto;background:var(--p1);color:#fff;border-color:var(--p1)}.rmc-preview-input{position:absolute;bottom:0;left:0;right:0;padding:9px;background:#fff;border-top:1px solid #eee;display:flex;gap:7px}.rmc-preview-input div{flex:1;border:1px solid #ddd;border-radius:10px;padding:9px;color:#98a2b3;font-size:11px}.rmc-preview-input b{width:35px;height:35px;border-radius:10px;background:var(--p1);color:#fff;display:grid;place-items:center}.rmc-preview-button{position:absolute;right:18px;bottom:18px;width:58px;height:58px;border-radius:var(--rad);background:linear-gradient(135deg,var(--p1),var(--p2));box-shadow:0 10px 25px rgba(71,26,255,.3);display:grid;place-items:center}.rmc-preview-button img{width:58px;height:58px;border-radius:var(--rad)}
.rmc-code{background:#101828;color:#e4e7ec;border-radius:11px;padding:13px;font-size:12px;overflow:auto}.rmc-status{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #eef0f4}.rmc-status:last-child{border-bottom:0}.rmc-copy{cursor:pointer;border:1px solid var(--line);background:#fff;border-radius:9px;padding:7px 10px;font-size:12px}.rmc-range{display:flex;gap:10px;align-items:center}.rmc-range input{width:100%}.rmc-range output{width:45px;text-align:center;font-weight:700}.rmc-color{height:42px;padding:3px!important}.rmc-mini{font-size:11px;color:#98a2b3}
.rmc-field{min-width:0}.rmc-field label{min-height:18px;display:flex;align-items:center}.rmc-field input[type="text"],.rmc-field input[type="password"],.rmc-field input[type="number"],.rmc-field textarea,.rmc-field select{height:44px;border-radius:12px;border:1px solid #dfe3eb;background:#fff;padding:10px 13px;box-shadow:0 1px 2px rgba(16,24,40,.03);transition:border-color .16s,box-shadow .16s,background .16s}.rmc-field textarea{height:auto;min-height:96px;resize:vertical}.rmc-field input:focus,.rmc-field textarea:focus,.rmc-field select:focus{border-color:#8b78ff;box-shadow:0 0 0 4px rgba(71,26,255,.09)}.rmc-field input[type="color"]{width:100%;height:44px;border-radius:12px;padding:4px!important}.rmc-upload-card{padding:14px 16px;border:1px solid #e3e6ed;border-radius:14px;background:#fafbfc;display:flex;align-items:center;gap:16px}.rmc-upload-card>img{width:64px;height:64px;border-radius:15px;flex:0 0 64px}.rmc-upload-content{min-width:0;display:flex;flex-direction:column;gap:7px}.rmc-upload-content strong{font-size:13px;color:#344054}.rmc-upload-content input[type="file"]{height:auto;border:0;padding:0;background:transparent;box-shadow:none}.rmc-upload-content input[type="file"]::file-selector-button{border:1px solid #d8dce5;background:#fff;border-radius:10px;padding:9px 12px;font-weight:650;color:#344054;cursor:pointer;margin-right:9px}.rmc-position-option{height:44px;box-sizing:border-box}.rmc-range{height:44px;padding:0 12px;border:1px solid #dfe3eb;border-radius:12px;background:#fafbfc}.rmc-range output{width:40px}.rmc-actions{padding-top:2px}.rmc-primary{min-height:44px;padding:11px 18px;border-radius:12px}.rmc-choice{height:auto;box-sizing:border-box}
@media(max-width:1000px){.rmc-grid{grid-template-columns:repeat(2,1fr)}.rmc-layout{grid-template-columns:1fr}.rmc-preview{position:relative;top:auto}.rmc-fields{grid-template-columns:1fr}}

/* Unified widget editor controls */
.rmc-widget-editor .rmc-panel{border-radius:16px}
.rmc-widget-editor .rmc-field{min-width:0}
.rmc-widget-editor .rmc-field>label{font-size:13px;font-weight:700;color:#344054;line-height:18px;margin-bottom:8px}
.rmc-widget-editor .rmc-field input[type="text"],.rmc-widget-editor .rmc-field input[type="password"],.rmc-widget-editor .rmc-field input[type="number"],.rmc-widget-editor .rmc-field textarea,.rmc-widget-editor .rmc-field select,.rmc-widget-editor .rmc-range{width:100%;box-sizing:border-box;min-height:44px;border:1px solid #dfe3eb;border-radius:12px;background:#fff;box-shadow:0 1px 2px rgba(16,24,40,.03);transition:border-color .16s,box-shadow .16s,background .16s}
.rmc-widget-editor .rmc-field input[type="text"],.rmc-widget-editor .rmc-field input[type="password"],.rmc-widget-editor .rmc-field input[type="number"],.rmc-widget-editor .rmc-field textarea,.rmc-widget-editor .rmc-field select{padding:10px 13px;font-size:14px;color:#101828;outline:none}
.rmc-widget-editor .rmc-field textarea{min-height:96px;resize:vertical}
.rmc-widget-editor .rmc-field input:focus,.rmc-widget-editor .rmc-field textarea:focus,.rmc-widget-editor .rmc-field select:focus{border-color:#8b78ff;box-shadow:0 0 0 4px rgba(71,26,255,.09)}
.rmc-widget-editor .rmc-help{font-size:12px;line-height:1.45;color:#98a2b3;margin-top:7px}
.rmc-widget-editor .rmc-position{gap:10px}
.rmc-widget-editor .rmc-position-option{height:44px;min-width:0;flex:1;justify-content:center;padding:0 14px;border:1px solid #dfe3eb;border-radius:12px;background:#fff;box-sizing:border-box}
.rmc-widget-editor .rmc-actions{gap:10px;margin-top:20px}
.rmc-widget-editor .rmc-primary,.rmc-widget-editor .rmc-secondary{min-height:44px;padding:0 18px;border-radius:12px;font-size:14px}
.rmc-widget-editor .rmc-upload-card{width:100%;min-height:92px;box-sizing:border-box;padding:12px 14px;border:1px solid #dfe3eb;border-radius:12px;background:#fafbfc;display:flex;align-items:center;gap:14px}
.rmc-widget-editor .rmc-upload-card>img{width:64px;height:64px;flex:0 0 64px;border-radius:14px;object-fit:cover;border:1px solid #e3e7ee;background:#fff}
.rmc-widget-editor .rmc-upload-content{min-width:0;flex:1;display:flex;flex-direction:column;gap:6px}
.rmc-widget-editor .rmc-upload-content strong{font-size:13px;color:#344054;font-weight:700}
.rmc-widget-editor .rmc-file-control{width:100%!important;height:40px!important;min-height:40px!important;padding:6px 8px!important;border:0!important;background:transparent!important;box-shadow:none!important;font-size:13px!important}
.rmc-widget-editor .rmc-file-control::file-selector-button{height:34px;border:1px solid #d8dce5;background:#fff;border-radius:9px;padding:0 12px;font-weight:650;color:#344054;cursor:pointer;margin-right:8px}
.rmc-widget-editor .rmc-range{display:flex;align-items:center;gap:12px;padding:0 12px;background:#fafbfc}
.rmc-widget-editor .rmc-range input[type="range"]{flex:1;width:100%;margin:0;accent-color:#471AFF}
.rmc-widget-editor .rmc-range output{min-width:42px;text-align:right;font-size:13px;font-weight:700;color:#475467}
.rmc-widget-editor .rmc-switch{min-height:44px;padding:0 12px;border:1px solid #dfe3eb;border-radius:12px;background:#fafbfc}

@media(max-width:600px){.rmc-button-style-grid{grid-template-columns:1fr}.rmc-grid{grid-template-columns:1fr}.rmc-hero{padding:22px}.rmc-hero-brand{display:none}.rmc-preview-chat{width:calc(100% - 28px);right:14px}.rmc-preview-button{right:16px}}

/* Compact dashboard actions + unified MAX connection form */
.rmc-admin .rmc-actions{align-items:center}
.rmc-admin .rmc-actions a.rmc-primary,.rmc-admin .rmc-actions a.rmc-secondary{display:inline-flex;align-items:center;justify-content:center;width:auto;min-width:0;height:42px;box-sizing:border-box;padding:0 16px;line-height:1;text-decoration:none;white-space:nowrap}
.rmc-admin .rmc-actions button.rmc-primary,.rmc-admin .rmc-actions button.rmc-secondary{display:inline-flex;align-items:center;justify-content:center;width:auto;min-width:0;height:42px;box-sizing:border-box;padding:0 16px;line-height:1;white-space:nowrap}
.rmc-admin .rmc-actions a.rmc-primary,.rmc-admin .rmc-actions button.rmc-primary{border-radius:11px;font-size:13px}
.rmc-admin .rmc-actions a.rmc-secondary,.rmc-admin .rmc-actions button.rmc-secondary{border:1px solid #dfe3eb;background:#fff;border-radius:11px;font-size:13px;color:#344054}
.rmc-admin .rmc-actions a.rmc-secondary:hover,.rmc-admin .rmc-actions button.rmc-secondary:hover{border-color:#c9c1ff;background:#faf9ff;color:#471AFF}
.rmc-admin .rmc-panel form .rmc-actions{margin-top:18px}
.rmc-admin .rmc-panel .rmc-fields{gap:18px 16px}
.rmc-admin .rmc-panel .rmc-field>label{font-size:13px;font-weight:700;color:#344054;line-height:18px;margin-bottom:8px}
.rmc-admin .rmc-panel .rmc-field input[type=text],.rmc-admin .rmc-panel .rmc-field input[type=password],.rmc-admin .rmc-panel .rmc-field input[type=number],.rmc-admin .rmc-panel .rmc-field select,.rmc-admin .rmc-panel .rmc-field textarea{height:44px;width:100%;box-sizing:border-box;padding:10px 13px;border:1px solid #dfe3eb;border-radius:12px;background:#fff;color:#101828;font-size:14px;outline:none;box-shadow:0 1px 2px rgba(16,24,40,.03);transition:border-color .16s,box-shadow .16s,background .16s}
.rmc-admin .rmc-panel .rmc-field input:focus,.rmc-admin .rmc-panel .rmc-field select:focus,.rmc-admin .rmc-panel .rmc-field textarea:focus{border-color:#8b78ff;box-shadow:0 0 0 4px rgba(71,26,255,.09)}
.rmc-admin .rmc-panel .rmc-field input::placeholder,.rmc-admin .rmc-panel .rmc-field textarea::placeholder{color:#98a2b3}
.rmc-admin .rmc-panel .rmc-help{font-size:12px;line-height:1.45;color:#98a2b3;margin-top:7px}
.rmc-admin .rmc-panel .rmc-code{border-radius:12px}
@media(max-width:600px){.rmc-admin .rmc-actions a.rmc-primary,.rmc-admin .rmc-actions a.rmc-secondary,.rmc-admin .rmc-actions button.rmc-primary,.rmc-admin .rmc-actions button.rmc-secondary{width:100%}}

.rmc-widget-editor .rmc-color-controls{display:flex;align-items:center;gap:10px;min-width:0}
.rmc-widget-editor .rmc-color-controls .rmc-color{flex:0 0 48px;width:48px;height:44px;padding:4px;border:1px solid #d8dce5;border-radius:10px;background:#fff;cursor:pointer}
.rmc-widget-editor .rmc-color-code{width:130px;max-width:100%;height:44px;border:1px solid #d8dce5;border-radius:10px;padding:0 12px;font:600 14px ui-monospace,SFMono-Regular,Consolas,monospace;letter-spacing:.2px;color:#344054;background:#fff;box-sizing:border-box}
.rmc-widget-editor .rmc-color-code:focus{outline:none;border-color:#8b78ff;box-shadow:0 0 0 4px rgba(71,26,255,.09)}

/* Refined live preview: mirror the actual widget header, messages and composer. */
.rmc-preview{padding:20px;background:linear-gradient(155deg,#f7f8fc,#eceef6);border-color:#e2e6f0;box-shadow:0 12px 32px rgba(24,30,60,.06)}
.rmc-preview h3{font-size:16px;font-weight:750;letter-spacing:-.25px;color:#20243a}.rmc-preview>small{display:block;font-size:12px;line-height:1.5;color:#7a8195}
.rmc-device{height:545px;background:linear-gradient(145deg,#fff,#f5f6fb);border:1px solid #e0e4ee;box-shadow:inset 0 0 0 4px rgba(255,255,255,.8)}
.rmc-preview-chat{display:flex;flex-direction:column;right:13px;bottom:78px;width:min(330px,calc(100% - 26px));height:430px;background:#f7f8fc;border:1px solid rgba(221,225,237,.9);border-radius:20px;box-shadow:0 16px 42px rgba(24,20,55,.2);}
.rmc-preview-head{flex:0 0 auto;min-height:66px;padding:13px 14px;box-sizing:border-box;gap:10px;background:linear-gradient(135deg,var(--p1),var(--p2));}
.rmc-preview-head .rmc-admin-preview-crop{width:38px;height:38px;flex:0 0 38px;border-radius:12px;background:rgba(255,255,255,.2)}
.rmc-preview-head-copy{min-width:0;flex:1}.rmc-preview-head strong{font-size:14px;font-weight:750;line-height:1.2;overflow-wrap:anywhere}.rmc-preview-head .rmc-preview-status{display:flex;align-items:center;gap:7px;margin-top:5px;font-size:11px;opacity:1}.rmc-preview-head .rmc-preview-status>span:last-child{font-size:11px;line-height:1.2;opacity:.9}
.rmc-preview-status-dot{position:relative;display:inline-block;width:7px;height:7px;flex:0 0 7px;border-radius:50%;background:#22c55e;box-shadow:0 0 0 2px rgba(34,197,94,.16)}
.rmc-preview-status-dot:before,.rmc-preview-status-dot:after{content:"";position:absolute;inset:-4px;border:1px solid rgba(34,197,94,.8);border-radius:50%;animation:rmc-preview-pulse 1.8s ease-out infinite}
.rmc-preview-status-dot:after{animation-delay:.9s}.rmc-preview-status-dot.is-offline{background:#ef4444;box-shadow:0 0 0 2px rgba(239,68,68,.16)}.rmc-preview-status-dot.is-offline:before,.rmc-preview-status-dot.is-offline:after{border-color:rgba(239,68,68,.8)}@keyframes rmc-preview-pulse{0%{transform:scale(.55);opacity:.95}100%{transform:scale(1.8);opacity:0}}
.rmc-preview-body{display:flex;flex:1 1 auto;min-height:0;height:auto;flex-direction:column;justify-content:flex-end;gap:12px;overflow:hidden;padding:14px 12px 12px;background:linear-gradient(180deg,#f8f9fd,#f1f3f9);box-sizing:border-box}
/* Latest preview refinements: messages start near the top and no timestamps are shown. */
.rmc-preview-body{justify-content:flex-start!important}
.rmc-preview-message time,.rmc-preview-message .rmc-bubble time{display:none!important}
.rmc-field label output{margin-left:6px;white-space:nowrap}
.rmc-field label output::after{content:" ";white-space:pre}
.rmc-field label{column-gap:5px}
.rmc-preview-button{overflow:visible}
.rmc-preview-button:after{content:"";position:absolute;right:-4px;bottom:-4px;top:auto;width:22px;height:22px;border-radius:50%;background:#22c55e;border:4px solid #fff;box-sizing:border-box;box-shadow:0 2px 7px rgba(16,24,40,.18);z-index:10}
.rmc-preview-status-dot{order:2;margin-left:4px}

.rmc-preview-message{display:flex;flex-direction:column;max-width:88%;gap:4px}.rmc-preview-message.incoming{align-self:flex-start;align-items:flex-start}.rmc-preview-message.outgoing{align-self:flex-end;align-items:flex-end}.rmc-preview-sender{font-size:11px;font-weight:750;color:#34394b;margin:0 0 1px 3px}.rmc-bubble{width:auto;max-width:100%;box-sizing:border-box;padding:9px 11px;border-radius:14px 14px 14px 5px;background:#fff;border:1px solid #e1e5ef;box-shadow:0 3px 10px rgba(26,34,60,.04);font-size:12px;line-height:1.4;color:#34394b;margin:0;overflow-wrap:anywhere}.rmc-bubble.out{border-radius:14px 14px 5px 14px;margin:0;background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff;border-color:transparent}.rmc-preview-message time{font-size:9px;color:#81889b;padding:0 3px;line-height:1}
.rmc-preview-input{position:relative;flex:0 0 auto;align-items:center;gap:8px;padding:10px;background:#fff;border-top:1px solid #e8eaf1;box-sizing:border-box;min-height:65px}.rmc-preview-attach,.rmc-preview-send{appearance:none;border:0;display:flex;align-items:center;justify-content:center;flex:0 0 38px;width:38px;height:38px;padding:0;border-radius:12px;color:#fff;background:linear-gradient(135deg,var(--p1),var(--p2));box-shadow:0 5px 14px rgba(71,26,255,.16);cursor:default}.rmc-preview-attach svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.rmc-preview-send svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.rmc-preview-placeholder{min-width:0;flex:1;height:38px;display:flex;align-items:center;box-sizing:border-box;padding:0 11px;border:1px solid #dfe3ed;border-radius:12px;background:#f5f6fa;color:#8b92a1;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rmc-preview-button{z-index:2;right:16px;bottom:16px;overflow:visible}.rmc-preview-button:after{content:"";position:absolute;right:-3px;bottom:-3px;width:12px;height:12px;border-radius:50%;background:#22c55e;border:3px solid #fff;box-shadow:0 2px 6px rgba(16,24,40,.14)}
@media(prefers-reduced-motion:reduce){.rmc-preview-status-dot:before,.rmc-preview-status-dot:after{animation:none}}
/* Final alignment fixes for the editor preview */
.rmc-preview-head .rmc-preview-status{display:flex;align-items:center;justify-content:flex-start;gap:8px}
.rmc-preview-head .rmc-preview-status>span:last-child{order:1}
.rmc-preview-head .rmc-preview-status .rmc-preview-status-dot{order:2;margin-left:1px}
.rmc-preview-message{position:relative;gap:5px}
.rmc-preview-message .rmc-bubble{position:relative;padding-bottom:23px;min-width:84px}
.rmc-preview-message .rmc-bubble time{position:absolute;right:9px;bottom:6px;display:block;margin:0;padding:0;font-size:9px;line-height:1;color:rgba(52,57,75,.62);white-space:nowrap}
.rmc-preview-message .rmc-bubble.out time{color:rgba(255,255,255,.78)}
.rmc-preview-body{--p1:#5b5cf6;--p2:#8058f5}
.rmc-preview-body .rmc-bubble.out{background:linear-gradient(135deg,var(--p1),var(--p2));border-color:transparent;color:#fff}
.rmc-preview-input .rmc-preview-attach,.rmc-preview-input .rmc-preview-send{background:linear-gradient(135deg,var(--p1),var(--p2));color:#fff;border:0}
.rmc-preview-input .rmc-preview-attach svg,.rmc-preview-input .rmc-preview-send svg{display:block}
.rmc-preview-sender{line-height:1.25}

/* Preview parity: client bubbles have no sender label or obsolete timestamp spacing. */
.rmc-preview-message.outgoing .rmc-preview-sender{display:none!important}
.rmc-preview-message .rmc-bubble{padding-bottom:9px!important;min-width:0!important}
.rmc-preview-message .rmc-bubble time{display:none!important}
/* Keep header and message avatars consistent with the launcher icon shape; remove white backing and use editor accent border. */
.rmc-preview-head .rmc-admin-preview-crop{background:transparent!important;border:1px solid var(--p1,#471AFF)!important;box-sizing:border-box!important;overflow:hidden!important}
.rmc-root .rmc-box header .rmc-head-image-frame{background:transparent!important;border:1px solid var(--rmc-color,#471AFF)!important;box-sizing:border-box!important}
.rmc-root .rmc-box header .rmc-head-image-frame img{background:transparent!important}
.rmc-root .rmc-box .rmc-msg.rmc-in .rmc-admin-avatar{background:transparent!important;border:1px solid var(--rmc-color,#471AFF)!important;box-sizing:border-box!important}

/* Dashboard preview repair: isolate layout rules so overview styles cannot collapse its widget. */
#rmc-dashboard-device{position:relative;box-sizing:border-box;min-height:515px;overflow:hidden}
#rmc-dashboard-chat{position:absolute!important;display:flex!important;flex-direction:column!important;box-sizing:border-box!important;width:min(330px,calc(100% - 26px))!important;height:430px!important;max-height:calc(100% - 92px)!important;right:13px!important;bottom:78px!important;left:auto!important;top:auto!important;overflow:hidden!important;border-radius:20px!important;background:#f7f8fc!important}
#rmc-dashboard-head{position:relative!important;display:flex!important;align-items:center!important;flex:0 0 auto!important;min-height:66px!important;padding:13px 82px 13px 14px!important;gap:10px!important;box-sizing:border-box!important;border-radius:19px 19px 0 0!important}
#rmc-dashboard-head>.rmc-admin-preview-crop{display:block!important;width:38px!important;height:38px!important;flex:0 0 38px!important;border:0!important;background:transparent!important;box-sizing:border-box!important;overflow:hidden!important}
#rmc-dashboard-head>.rmc-admin-preview-crop img{display:block!important;width:100%!important;height:100%!important;max-width:none!important;object-fit:cover!important}
#rmc-dashboard-head .rmc-preview-head-copy{display:flex!important;flex:1 1 auto!important;flex-direction:column!important;min-width:0!important;overflow:hidden}
#rmc-dashboard-head .rmc-preview-window-actions{position:absolute!important;right:10px!important;top:50%!important;transform:translateY(-50%)!important;display:flex!important;gap:5px!important}
#rmc-dashboard-head .rmc-preview-window-actions button{width:28px!important;height:28px!important;flex:0 0 28px!important;display:flex!important;align-items:center!important;justify-content:center!important;padding:0!important;border:0!important;border-radius:8px!important;background:rgba(255,255,255,.16)!important;color:#fff!important;font-size:22px!important;line-height:1!important}
#rmc-dashboard-head .rmc-preview-status{display:flex!important;align-items:center!important;gap:7px!important;min-width:0!important}
#rmc-dashboard-chat>.rmc-preview-body{position:relative!important;display:flex!important;flex:1 1 auto!important;flex-direction:column!important;justify-content:flex-start!important;gap:12px!important;min-height:0!important;height:auto!important;overflow:hidden!important;padding:14px 12px 12px!important;box-sizing:border-box!important;background:linear-gradient(180deg,#f8f9fd,#f1f3f9)!important}
#rmc-dashboard-chat .rmc-preview-message{display:flex!important;flex-direction:row!important;align-items:flex-end!important;gap:7px!important;max-width:100%!important;min-width:0!important}
#rmc-dashboard-chat .rmc-preview-message-avatar{display:block!important;width:26px!important;height:26px!important;flex:0 0 26px!important;overflow:hidden!important;margin-bottom:1px!important;background:transparent!important}
#rmc-dashboard-chat .rmc-preview-message-avatar img{display:block!important;width:100%!important;height:100%!important;object-fit:cover!important;border:0!important;box-shadow:none!important}
#rmc-dashboard-chat .rmc-preview-message-copy{display:flex!important;flex-direction:column!important;align-items:flex-start!important;min-width:0!important;max-width:calc(100% - 33px)!important}
#rmc-dashboard-chat .rmc-preview-message-copy .rmc-bubble{display:flex!important;flex-direction:column!important;align-items:flex-start!important;gap:4px!important;max-width:100%!important;min-width:0!important;padding:9px 11px!important;box-sizing:border-box!important;overflow-wrap:anywhere!important}
#rmc-dashboard-chat .rmc-preview-sender-inside{display:block!important;margin:0!important;padding:0!important;font-size:10px!important;font-weight:750!important;line-height:1.2!important;color:#667085!important}
#rmc-dashboard-chat .rmc-preview-message.outgoing{align-self:flex-end!important;flex-direction:column!important;align-items:flex-end!important}
#rmc-dashboard-chat .rmc-preview-input{position:relative!important;display:flex!important;flex:0 0 auto!important;align-items:center!important;gap:8px!important;min-height:65px!important;padding:10px!important;box-sizing:border-box!important;background:#fff!important;border-top:1px solid #e8eaf1!important}
#rmc-dashboard-chat .rmc-preview-attach,#rmc-dashboard-chat .rmc-preview-send{display:flex!important;align-items:center!important;justify-content:center!important;flex:0 0 38px!important;width:38px!important;height:38px!important;padding:0!important;border:0!important;border-radius:12px!important;color:#fff!important;box-sizing:border-box!important}
#rmc-dashboard-chat .rmc-preview-attach svg,#rmc-dashboard-chat .rmc-preview-send svg{display:block!important;width:19px!important;height:19px!important;fill:none!important;stroke:currentColor!important;stroke-width:1.8!important;stroke-linecap:round!important;stroke-linejoin:round!important}
#rmc-dashboard-chat .rmc-preview-placeholder{display:flex!important;align-items:center!important;flex:1 1 auto!important;min-width:0!important;height:38px!important;box-sizing:border-box!important;overflow:hidden!important;white-space:nowrap!important;text-overflow:ellipsis!important}
#rmc-dashboard-device>.rmc-preview-button{position:absolute!important;z-index:3!important;right:16px!important;bottom:16px!important;display:grid!important;place-items:center!important;overflow:visible!important;box-sizing:border-box!important}
#rmc-dashboard-device>.rmc-preview-button .rmc-admin-preview-button-crop{display:block!important;width:100%!important;height:100%!important;overflow:hidden!important;box-sizing:border-box!important}
#rmc-dashboard-device>.rmc-preview-button .rmc-admin-preview-button-crop img{border-radius:inherit!important;overflow:hidden!important}
#rmc-dashboard-device>.rmc-preview-button{--rad:<?=$radius?>px}
#rmc-dashboard-device>.rmc-preview-button .rmc-admin-preview-button-crop{border-radius:<?=$buttonIconShape==='circle'?'50%':(int)$radius.'px'?>!important}
#rmc-dashboard-device>.rmc-preview-button img{display:block!important;width:100%!important;height:100%!important;object-fit:cover!important}
/* Definitive Overview launcher cleanup: remove decorative tile from every layer. */
#rmc-dashboard-device>.rmc-preview-button,#rmc-dashboard-device>.rmc-preview-button:hover,#rmc-dashboard-device>.rmc-preview-button:focus,#rmc-dashboard-device>.rmc-preview-button:active{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;outline:0!important;box-shadow:none!important;filter:none!important}
#rmc-dashboard-device>.rmc-preview-button:before{content:none!important;display:none!important}
#rmc-dashboard-device>.rmc-preview-button>.rmc-admin-preview-button-crop,#rmc-dashboard-device>.rmc-preview-button>.rmc-admin-preview-button-crop img{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;outline:0!important;box-shadow:none!important}
.rmc-radius-control.is-disabled{opacity:.45;filter:grayscale(1)}.rmc-radius-control.is-disabled input{cursor:not-allowed}


/* Unified launcher status dot: exact 18px badge geometry used in both previews. */
#rmc-dashboard-device>.rmc-preview-button:after,
#rmc-preview-device>.rmc-preview-button:after{
 content:""!important;position:absolute!important;right:-3px!important;bottom:-3px!important;top:auto!important;left:auto!important;
 width:18px!important;height:18px!important;min-width:18px!important;min-height:18px!important;box-sizing:border-box!important;
 border-radius:50%!important;background:#22c55e!important;background-color:#22c55e!important;
 border:3px solid #fff!important;box-shadow:0 2px 6px rgba(16,24,40,.14)!important;z-index:20!important;display:block!important;
}
#rmc-dashboard-device>.rmc-preview-button.is-offline:after,
#rmc-preview-device>.rmc-preview-button.is-offline:after{background:#ef4444!important;background-color:#ef4444!important}
#rmc-dashboard-device>.rmc-preview-button,
#rmc-preview-device>.rmc-preview-button{position:absolute;overflow:visible!important}
</style>
<div class="rmc-admin">
  <div class="rmc-hero">
    <h1>Онлайн-чат МАКС</h1>
    <p>Современный онлайн-чат для сайта с маршрутизацией обращений через MAX.</p>
    <div class="rmc-hero-brand"><img src="/bitrix/js/kdigitals.max/max-icon.svg" alt="MAX"><span>MAX</span></div>
  </div>

  <div class="rmc-tabs">
    <a class="rmc-tab <?=$activeTab==='dashboard'?'active':''?>" href="?tab=dashboard">▦ Обзор</a>
    <a class="rmc-tab <?=$activeTab==='connection'?'active':''?>" href="?tab=connection">↯ Подключение MAX</a>
    <a class="rmc-tab <?=$activeTab==='widget'?'active':''?>" href="?tab=widget">✦ Редактор виджета</a>
    <a class="rmc-tab <?=$activeTab==='advanced'?'active':''?>" href="?tab=advanced">⚙ Дополнительно</a>
  </div>

  <?=$testResult?>

<?php if ($activeTab === 'dashboard'): ?>
  <div class="rmc-grid">
    <div class="rmc-card"><div class="k">Виджет</div><div class="v"><span class="rmc-dot <?=Settings::enabled()?'':'off'?>"></span><?=Settings::enabled()?'Включён':'Выключен'?></div></div>
    <div class="rmc-card"><div class="k">MAX API</div><div class="v"><span class="rmc-dot <?=Settings::get('access_token')?'':'off'?>"></span><?=Settings::get('access_token')?'Настроен':'Не настроен'?></div></div>
    <div class="rmc-card"><div class="k">Чат / канал</div><div class="v" style="font-size:17px"><?=htmlspecialcharsbx($chatId ?: 'Не указан')?></div></div>
    <div class="rmc-card"><div class="k">Webhook</div><div class="v"><span class="rmc-dot <?=Settings::get('webhook_secret')?'':'off'?>"></span><?=Settings::get('webhook_secret')?'Настроен':'Не подключён'?></div></div>
  </div>
  <div class="rmc-layout" style="margin-top:18px">
    <div>
      <div class="rmc-panel">
        <h2>Добро пожаловать в Онлайн-чат МАКС</h2>
        <div class="desc">Все основные действия теперь собраны в одном современном интерфейсе.</div>
        <div class="rmc-status"><span>1. Подключите токен MAX</span><strong><?=Settings::get('access_token')?'✓ Готово':'Не выполнено'?></strong></div>
        <div class="rmc-status"><span>2. Укажите приватный чат / канал</span><strong><?=Settings::chatId()?'✓ Готово':'Не выполнено'?></strong></div>
        <div class="rmc-status"><span>3. Подключите Webhook</span><strong><?=Settings::get('webhook_secret')?'✓ Готово':'Не выполнено'?></strong></div>
        <div class="rmc-status"><span>4. Настройте внешний вид виджета</span><strong>→</strong></div>
        <div class="rmc-actions"><a class="rmc-primary" href="?tab=connection">Настроить MAX</a><a class="rmc-secondary" href="?tab=widget">Открыть редактор</a></div>
      </div>
      <div class="rmc-panel"><h2>Как работает чат</h2><div class="desc">Каждый посетитель получает отдельное обращение. Ответ менеджера через «Ответить» в MAX возвращается только нужному посетителю.</div><div class="rmc-code">Сайт → Обращение #123 → приватный MAX-чат → Reply менеджера → только клиент #123</div></div>
    </div>
    <div class="rmc-preview" style="min-height:300px"><h3>Быстрый просмотр</h3><small>Текущий вид виджета — элементы и статус соответствуют редактору.</small><div class="rmc-device" style="height:515px" id="rmc-dashboard-device"><div class="rmc-preview-chat" id="rmc-dashboard-chat" style="--p1:<?=$color?>;--p2:<?=$headerColor2?>"><div class="rmc-preview-head" id="rmc-dashboard-head" style="--p1:<?=$color?>;--p2:<?=$headerColor2?>"><span class="rmc-admin-preview-crop" style="border-radius:<?=$avatarShape==='circle'?'50%':'0px'?>;overflow:hidden;width:38px;height:38px;flex:0 0 38px"><img src="<?=htmlspecialcharsbx($avatarUrl)?>" alt="" style="width:100%;height:100%;object-fit:cover"></span><div class="rmc-preview-head-copy"><strong><?=htmlspecialcharsbx($title)?></strong><span class="rmc-preview-status"><span id="rmc-dashboard-status-text"><?=htmlspecialcharsbx($subtitle)?></span><i class="rmc-preview-status-dot" id="rmc-dashboard-status-dot"></i></span></div><div class="rmc-preview-window-actions"><button type="button" aria-label="Развернуть" title="Развернуть"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4H4v4M16 4h4v4M8 20H4v-4M20 16v4h-4"/></svg></button><button type="button" aria-label="Закрыть" title="Закрыть">×</button></div></div><div class="rmc-preview-body"><div class="rmc-preview-message incoming"><span class="rmc-preview-message-avatar" style="border-radius:<?=$avatarShape==='circle'?'50%':'0px'?>"><img src="<?=htmlspecialcharsbx($avatarUrl)?>" alt=""></span><div class="rmc-preview-message-copy"><span class="rmc-bubble rmc-bubble-incoming"><small class="rmc-preview-sender rmc-preview-sender-inside"><?=htmlspecialcharsbx($managerName ?: 'Администратор')?></small><span id="rmc-dashboard-greeting"><?=htmlspecialcharsbx($greeting)?></span></span></div></div><div class="rmc-preview-message outgoing"><span class="rmc-bubble out" style="background:linear-gradient(135deg,<?=$color?> 0%,<?=$color?> 55%,<?=$headerColor2?> 100%)!important;background-color:<?=$color?>!important;color:#fff!important;border:0!important;border-color:transparent!important;box-shadow:none!important">Здравствуйте!</span></div></div><div class="rmc-preview-input"><button type="button" class="rmc-preview-attach" aria-label="Прикрепить файл"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21.4 11.1 12 20.5a6 6 0 0 1-8.5-8.5l10-10a4 4 0 0 1 5.7 5.7l-10 10a2 2 0 0 1-2.8-2.8l9.2-9.2"/></svg></button><div class="rmc-preview-placeholder">Напишите сообщение...</div><button type="button" class="rmc-preview-send" aria-label="Отправить"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg></button></div></div><div class="rmc-preview-button" style="--p1:<?=$color?>;--p2:<?=$headerColor2?>;--rad:<?=$radius?>px;width:<?=$buttonSize?>px;height:<?=$buttonSize?>px"><span class="rmc-admin-preview-button-crop" style="border-radius:<?=$buttonIconShape==='circle'?'50%':(int)$radius.'px'?>"><img src="<?=htmlspecialcharsbx($buttonIconUrl)?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit"></span></div></div></div>
<script>(function(){var dot=document.getElementById('rmc-dashboard-status-dot'),txt=document.getElementById('rmc-dashboard-status-text'),launcher=document.querySelector('#rmc-dashboard-device>.rmc-preview-button');function update(){if(!dot||!txt)return;var now=new Date(),m=now.getHours()*60+now.getMinutes(),a=<?=\Bitrix\Main\Web\Json::encode($workStartTime ?: '09:00', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)?>.split(':').map(Number),b=<?=\Bitrix\Main\Web\Json::encode($workEndTime ?: '17:00', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)?>.split(':').map(Number),start=a[0]*60+a[1],end=b[0]*60+b[1],online=start<=end?(m>=start&&m<end):(m>=start||m<end);dot.classList.toggle('is-offline',!online);if(launcher)launcher.classList.toggle('is-offline',!online);txt.textContent=online?'Операторы онлайн':'Операторы оффлайн';var greeting=document.getElementById('rmc-dashboard-greeting');if(greeting)greeting.textContent=online?<?=\Bitrix\Main\Web\Json::encode($greeting, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)?>:'Мы не в сети, но вы можете написать нам. Ответим в рабочее время: с '+<?=\Bitrix\Main\Web\Json::encode($workStartTime ?: '09:00', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)?>+' до '+<?=\Bitrix\Main\Web\Json::encode($workEndTime ?: '17:00', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)?>+'.';}update();window.setInterval(update,10000);})();</script>
  </div>

<?php elseif ($activeTab === 'connection'): ?>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="sessid" value="<?=bitrix_sessid()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="tab" value="connection">
    <div class="rmc-panel"><h2>Подключение MAX</h2><div class="desc">Укажите данные бота и приватного чата, куда будут поступать обращения.</div><div class="rmc-fields">
      <div class="rmc-field full"><label>MAX Bot Access Token</label><input type="password" name="access_token" value="<?=htmlspecialcharsbx($token)?>" placeholder="Вставьте токен бота"><div class="rmc-help">Токен хранится в настройках Bitrix и используется только сервером.</div></div>
      <div class="rmc-field"><label>ID приватного чата / канала</label><input type="text" name="max_chat_id" value="<?=htmlspecialcharsbx($chatId)?>" placeholder="Например: 123456789"><div class="rmc-help">Бот должен быть добавлен в этот чат.</div></div>
      <div class="rmc-field"><label>Webhook Secret</label><input type="text" name="webhook_secret" value="<?=htmlspecialcharsbx($secret)?>" placeholder="Можно создать автоматически"><div class="rmc-help">Секрет используется для проверки входящих событий.</div></div>
    </div><div class="rmc-actions"><button class="rmc-primary" type="submit">Сохранить подключение</button></form>
    <form method="post" enctype="multipart/form-data"><input type="hidden" name="sessid" value="<?=bitrix_sessid()?>"><input type="hidden" name="action" value="test"><input type="hidden" name="tab" value="connection"><button class="rmc-secondary">Проверить MAX API</button></form>
    <form method="post" enctype="multipart/form-data"><input type="hidden" name="sessid" value="<?=bitrix_sessid()?>"><input type="hidden" name="action" value="webhook"><input type="hidden" name="tab" value="connection"><button class="rmc-secondary">Подключить Webhook</button></form></div></div>
  </div>
  <div class="rmc-panel"><h2>Webhook</h2><div class="desc">Этот адрес принимает сообщения менеджеров из MAX и маршрутизирует их в нужный виджет.</div><div class="rmc-code"><?=htmlspecialcharsbx($webhookUrl)?></div><div class="rmc-help" style="margin-top:10px">Для production используйте HTTPS на 443.</div></div>

<?php elseif ($activeTab === 'widget'): ?>
  <div class="rmc-layout rmc-widget-editor"><div>
  <form method="post" enctype="multipart/form-data" id="rmc-widget-form"><input type="hidden" name="sessid" value="<?=bitrix_sessid()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="tab" value="widget">
    <div class="rmc-panel"><h2>Основное</h2><div class="desc">Настройте тексты и положение кнопки без изменения кода сайта.</div><div class="rmc-fields">
      <div class="rmc-field"><label>Название в шапке</label><input id="rmc-title" type="text" name="title" value="<?=htmlspecialcharsbx($title)?>"></div>
      <div class="rmc-field full"><label for="rmc-greeting">Первое приветствие</label><textarea id="rmc-greeting" name="greeting" rows="3"><?=htmlspecialcharsbx($greeting)?></textarea><div class="rmc-emoji-tools"><span>Добавить эмодзи</span><div class="rmc-emoji-list" role="group" aria-label="Эмодзи для приветствия"><?php foreach (["😀","😊","👋","🙂","😉","😍","🎉","❤️","👍","✨","🤝","💬","☀️","🙏","🌷","😎"] as $emoji): ?><button type="button" class="rmc-emoji-btn" data-emoji="<?=htmlspecialcharsbx($emoji)?>" aria-label="Вставить <?=htmlspecialcharsbx($emoji)?>"><?=htmlspecialcharsbx($emoji)?></button><?php endforeach; ?></div><small>Нажмите на эмодзи — он вставится в позицию курсора.</small></div></div>
      <div class="rmc-field"><label>Никнейм администрации</label><input id="rmc-manager-name" type="text" name="manager_name" maxlength="120" value="<?=htmlspecialcharsbx($managerName)?>" placeholder="Например: Анна"><div class="rmc-help">Такое имя будет показано над ответами администрации в чате посетителя.</div></div>
      <div class="rmc-field"><label>Положение кнопки</label><div class="rmc-position"><label class="rmc-position-option"><input type="radio" name="position" value="right" <?=$position==='right'?'checked':''?>><span>Справа</span></label><label class="rmc-position-option"><input type="radio" name="position" value="left" <?=$position==='left'?'checked':''?>><span>Слева</span></label></div><div class="rmc-help">Где показывать кнопку MAX на сайте.</div></div>
      <div class="rmc-field"><label>Текст кнопки / доступность</label><input type="text" name="button_text" value="<?=htmlspecialcharsbx($buttonText)?>"><div class="rmc-help">Текст используется как доступное описание кнопки.</div></div>
      <div class="rmc-field"><label>Начало рабочего дня</label><input type="time" id="rmc-work-start" name="work_start_time" value="<?=htmlspecialcharsbx($workStartTime)?>"><div class="rmc-help">С этого времени операторы отображаются онлайн. Используется местное время браузера посетителя.</div></div>
      <div class="rmc-field"><label>Окончание рабочего дня</label><input type="time" id="rmc-work-end" name="work_end_time" value="<?=htmlspecialcharsbx($workEndTime)?>"><div class="rmc-help">После этого времени индикатор операторов станет красным.</div></div>
    </div></div>
    <div class="rmc-panel"><h2>Внешний вид</h2><div class="desc">Цвета применяются к шапке, кнопке отправки и плавающей кнопке MAX.</div><div class="rmc-fields">
      <div class="rmc-field full"><label>Картинка в шапке чата</label><div class="rmc-upload-card"><span class="rmc-admin-crop-frame"><img id="rmc-avatar-preview" src="<?=htmlspecialcharsbx($avatarUrl)?>" alt="Аватар"></span><div class="rmc-upload-content"><strong>Изображение шапки</strong><input class="rmc-file-control" type="file" name="avatar_file" id="rmc-avatar-file" accept="image/jpeg,image/png,image/webp,image/gif"><div class="rmc-help">Показывается в шапке виджета. JPG, PNG, WEBP или GIF, до 5 МБ.</div></div></div>
        <div class="rmc-fields rmc-crop-controls">
          <div class="rmc-field"><label for="rmc-avatar-shape">Форма картинки</label><select id="rmc-avatar-shape" name="avatar_shape"><option value="square" <?=$avatarShape==='square'?'selected':''?>>Квадрат</option><option value="circle" <?=$avatarShape==='circle'?'selected':''?>>Круг</option></select></div>
          <div class="rmc-field"><label for="rmc-avatar-zoom">Масштаб изображения <output id="rmc-avatar-zoom-out"><?=$avatarZoom?>%</output></label><input id="rmc-avatar-zoom" type="range" name="avatar_zoom" min="100" max="200" step="1" value="<?=$avatarZoom?>"></div>
          <div class="rmc-field"><label for="rmc-avatar-x">Положение по горизонтали <output id="rmc-avatar-x-out"><?=$avatarX?>%</output></label><input id="rmc-avatar-x" type="range" name="avatar_x" min="0" max="100" step="1" value="<?=$avatarX?>"></div>
          <div class="rmc-field"><label for="rmc-avatar-y">Положение по вертикали <output id="rmc-avatar-y-out"><?=$avatarY?>%</output></label><input id="rmc-avatar-y" type="range" name="avatar_y" min="0" max="100" step="1" value="<?=$avatarY?>"></div>
        </div></div>
      <div class="rmc-field"><label>Цвет шапки чата — основной</label><div class="rmc-color-controls"><input id="rmc-color-picker" class="rmc-color" type="color" value="<?=htmlspecialcharsbx($color)?>" aria-label="Выбрать основной цвет"><input id="rmc-color" class="rmc-color-code" type="text" name="color" value="<?=htmlspecialcharsbx($color)?>" placeholder="#8b5cf6" pattern="^#[0-9a-fA-F]{6}$" maxlength="7" spellcheck="false" aria-label="HEX-код основного цвета"></div><div class="rmc-help">Первый цвет градиента шапки, кнопки и кнопки отправки.</div></div>
      <div class="rmc-field"><label>Цвет шапки чата — второй</label><div class="rmc-color-controls"><input id="rmc-color2" class="rmc-color" type="color" value="<?=htmlspecialcharsbx($headerColor2)?>" aria-label="Выбрать второй цвет"><input id="rmc-color2-code" class="rmc-color-code" type="text" name="header_color_2" value="<?=htmlspecialcharsbx($headerColor2)?>" placeholder="#00bfff" pattern="^#[0-9a-fA-F]{6}$" maxlength="7" spellcheck="false" aria-label="HEX-код второго цвета"></div><div class="rmc-help">Второй цвет плавно переходит в первый и завершает градиент шапки.</div></div>
      <div class="rmc-field full"><label>Иконка кнопки открытия</label><div class="rmc-upload-card"><span class="rmc-admin-crop-frame"><img id="rmc-button-icon-preview" src="<?=htmlspecialcharsbx($buttonIconUrl)?>" alt="Иконка кнопки"></span><div class="rmc-upload-content"><strong>Изображение кнопки</strong><input class="rmc-file-control" type="file" name="button_icon_file" id="rmc-button-icon-file" accept="image/jpeg,image/png,image/webp,image/gif"><div class="rmc-help">Если файл не выбран, используется стандартная иконка «М». JPG, PNG, WEBP или GIF, до 5 МБ.</div></div></div>
        <div class="rmc-fields rmc-crop-controls">
          <div class="rmc-field"><label for="rmc-button-icon-shape">Форма картинки</label><select id="rmc-button-icon-shape" name="button_icon_shape"><option value="circle" <?=$buttonIconShape==='circle'?'selected':''?>>Круг</option><option value="square" <?=$buttonIconShape==='square'?'selected':''?>>Квадрат</option></select></div>
          <div class="rmc-field"><label for="rmc-button-icon-zoom">Масштаб изображения <output id="rmc-button-icon-zoom-out"><?=$buttonIconZoom?>%</output></label><input id="rmc-button-icon-zoom" type="range" name="button_icon_zoom" min="100" max="200" step="1" value="<?=$buttonIconZoom?>"></div>
          <div class="rmc-field"><label for="rmc-button-icon-x">Положение по горизонтали <output id="rmc-button-icon-x-out"><?=$buttonIconX?>%</output></label><input id="rmc-button-icon-x" type="range" name="button_icon_x" min="0" max="100" step="1" value="<?=$buttonIconX?>"></div>
          <div class="rmc-field"><label for="rmc-button-icon-y">Положение по вертикали <output id="rmc-button-icon-y-out"><?=$buttonIconY?>%</output></label><input id="rmc-button-icon-y" type="range" name="button_icon_y" min="0" max="100" step="1" value="<?=$buttonIconY?>"></div>
        </div></div>
      <div class="rmc-field"><label>Размер кнопки: <output id="rmc-size-out"><?=$buttonSize?></output> px</label><div class="rmc-range"><input id="rmc-size" type="range" name="button_size" min="52" max="82" value="<?=$buttonSize?>"><output id="rmc-size-out2"><?=$buttonSize?></output></div></div>
      <div class="rmc-field rmc-radius-control" id="rmc-radius-control"><label>Скругление: <output id="rmc-radius-out"><?=$radius?></output> px</label><div class="rmc-range"><input id="rmc-radius" type="range" name="border_radius" min="12" max="30" value="<?=$radius?>"><output id="rmc-radius-out2"><?=$radius?></output></div></div>
      <div class="rmc-field"><label>Отступ справа / слева</label><input type="number" name="offset_x" min="8" max="80" value="<?=$offsetX?>"></div>
      <div class="rmc-field"><label>Отступ снизу</label><input type="number" name="offset_y" min="8" max="80" value="<?=$offsetY?>"></div>
    </div><div class="rmc-actions"><button class="rmc-primary" type="submit">Сохранить виджет</button></div></div>
  </form></div>
  <div class="rmc-preview"><h3>Предпросмотр в реальном времени</h3><small>Изменяйте поля слева — макет обновится сразу.</small><div class="rmc-device" id="rmc-preview-device"><div class="rmc-preview-chat" id="rmc-preview-chat"><div class="rmc-preview-head" id="rmc-preview-head" style="--p1:<?=$color?>;--p2:<?=$headerColor2?>"><span class="rmc-admin-preview-crop"><img id="rmc-preview-avatar" src="<?=htmlspecialcharsbx($avatarUrl)?>"></span><div class="rmc-preview-head-copy"><strong id="rmc-preview-title"><?=htmlspecialcharsbx($title)?></strong><span class="rmc-preview-status"><span id="rmc-preview-subtitle"><?=htmlspecialcharsbx($subtitle)?></span><i class="rmc-preview-status-dot" id="rmc-preview-status-dot"></i></span></div><div class="rmc-preview-window-actions"><button type="button" aria-label="Развернуть" title="Развернуть"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4H4v4M16 4h4v4M8 20H4v-4M20 16v4h-4"/></svg></button><button type="button" aria-label="Закрыть" title="Закрыть">×</button></div></div><div class="rmc-preview-body" id="rmc-preview-body"><div class="rmc-preview-message incoming"><span class="rmc-preview-message-avatar"><img id="rmc-preview-message-avatar" src="<?=htmlspecialcharsbx($avatarUrl)?>" alt=""></span><div class="rmc-preview-message-copy"><span class="rmc-bubble rmc-bubble-incoming" id="rmc-preview-greeting"><small class="rmc-preview-sender rmc-preview-sender-inside" id="rmc-preview-manager-name"><?=htmlspecialcharsbx($managerName)?></small><span id="rmc-preview-greeting-text"><?=htmlspecialcharsbx($greeting)?></span></span></div></div><div class="rmc-preview-message outgoing"><small class="rmc-preview-sender">Вы</small><span class="rmc-bubble out">Здравствуйте!</span></div></div><div class="rmc-preview-input"><button type="button" class="rmc-preview-attach" aria-label="Прикрепить файл"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21.4 11.1 12 20.5a6 6 0 0 1-8.5-8.5l10-10a4 4 0 0 1 5.7 5.7l-10 10a2 2 0 0 1-2.8-2.8l9.2-9.2"/></svg></button><div class="rmc-preview-placeholder">Напишите сообщение...</div><button type="button" id="rmc-preview-send" class="rmc-preview-send" aria-label="Отправить"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg></button></div></div><div class="rmc-preview-button" id="rmc-preview-button" style="--p1:<?=$color?>;--p2:<?=$headerColor2?>;--rad:<?=$radius?>px"><span class="rmc-admin-preview-button-crop"><img id="rmc-preview-button-icon" src="<?=htmlspecialcharsbx($buttonIconUrl)?>"></span></div></div></div></div>

<style>
/* Branded, accessible dropdowns for shape selection and other editor selects. */
.rmc-admin .rmc-field select{appearance:none;-webkit-appearance:none;display:block;width:100%;min-height:44px;padding:11px 42px 11px 14px;border:1px solid #d9ddec;border-radius:12px;background-color:#fff;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23654cff' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;color:#24243b;font:600 13px/1.35 inherit;box-shadow:0 2px 5px rgba(31,28,75,.03);cursor:pointer;transition:border-color .18s,box-shadow .18s,background-color .18s}
.rmc-admin .rmc-field select:hover{border-color:#b9afff;background-color:#fcfbff}
.rmc-admin .rmc-field select:focus{outline:none;border-color:#765cff;box-shadow:0 0 0 3px rgba(101,76,255,.15)}
.rmc-admin .rmc-field select option{padding:10px;background:#fff;color:#24243b;font-weight:500}
.rmc-admin .rmc-crop-controls .rmc-field:first-child select{font-weight:700}
/* Custom shape picker: fully styled popup instead of the browser-native option list. */
.rmc-shape-picker{position:relative;width:100%;z-index:5}.rmc-shape-picker.is-open{z-index:30}.rmc-shape-picker select{position:absolute!important;width:1px!important;height:1px!important;min-height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important;opacity:0!important;pointer-events:none!important}.rmc-shape-trigger{display:flex;align-items:center;justify-content:space-between;gap:12px;width:100%;min-height:48px;padding:9px 13px;border:1px solid #dfe3eb;border-radius:13px;background:linear-gradient(180deg,#fff,#fbfaff);color:#24243b;font:600 13px inherit;text-align:left;cursor:pointer;box-shadow:0 2px 5px rgba(31,28,75,.04);transition:.18s}.rmc-shape-trigger:hover,.rmc-shape-picker.is-open .rmc-shape-trigger{border-color:#9a88ff;box-shadow:0 0 0 3px rgba(101,76,255,.10)}.rmc-shape-trigger-label{display:flex;align-items:center;gap:10px}.rmc-shape-glyph{width:27px;height:27px;display:inline-block;flex:0 0 27px;background:linear-gradient(135deg,#654cff,#a08bff);border-radius:5px;box-shadow:0 3px 8px rgba(101,76,255,.2)}.rmc-shape-glyph.circle{border-radius:50%}.rmc-shape-chevron{width:16px;height:16px;color:#765cff;transition:transform .18s}.rmc-shape-picker.is-open .rmc-shape-chevron{transform:rotate(180deg)}.rmc-shape-menu{position:absolute;left:0;right:0;top:calc(100% + 7px);padding:6px;background:#fff;border:1px solid #e5e1fb;border-radius:14px;box-shadow:0 16px 38px rgba(35,24,86,.17);display:none}.rmc-shape-picker.is-open .rmc-shape-menu{display:block;animation:rmcShapeIn .14s ease-out}@keyframes rmcShapeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.rmc-shape-option{display:flex;align-items:center;gap:11px;width:100%;padding:10px;border:0;border-radius:10px;background:transparent;color:#344054;text-align:left;font:600 13px inherit;cursor:pointer}.rmc-shape-option:hover{background:#f6f3ff}.rmc-shape-option[aria-selected=true]{background:#f0ecff;color:#4d31d2}.rmc-shape-option .rmc-shape-check{margin-left:auto;color:#654cff;font-size:16px;opacity:0}.rmc-shape-option[aria-selected=true] .rmc-shape-check{opacity:1}
/* Preview controls and admin message avatar should match the live widget. */
.rmc-preview-head{position:relative;padding-right:82px!important}
.rmc-preview-window-actions{position:absolute;right:10px;top:50%;transform:translateY(-50%);display:flex;align-items:center;gap:5px}
.rmc-preview-window-actions button{width:28px;height:28px;display:flex;align-items:center;justify-content:center;padding:0;border:0;border-radius:8px;background:rgba(255,255,255,.16);color:#fff;font-size:22px;line-height:1}
.rmc-preview-window-actions svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.rmc-preview-message.incoming{flex-direction:row!important;align-items:flex-end!important;gap:7px!important;max-width:100%!important}
.rmc-preview-message-avatar{width:26px;height:26px;flex:0 0 26px;display:block;overflow:hidden;border-radius:var(--rmc-preview-avatar-radius,0px);background:transparent;margin-bottom:1px}
.rmc-preview-message-avatar img{display:block;width:100%;height:100%;object-fit:cover;object-position:center;border:0!important;box-shadow:none!important;background:transparent!important}
.rmc-preview-message-copy{display:flex;flex-direction:column;align-items:flex-start;min-width:0;max-width:calc(100% - 33px);gap:4px}
.rmc-preview-message-copy .rmc-bubble{max-width:100%}

/* The incoming administrator name belongs inside the message bubble, above its text. */
.rmc-preview-message-copy .rmc-bubble-incoming{display:flex!important;flex-direction:column;align-items:flex-start;gap:4px;padding:9px 11px!important;}
.rmc-preview-message-copy .rmc-preview-sender-inside{display:block!important;margin:0!important;padding:0!important;font-size:10px!important;font-weight:750!important;line-height:1.2;color:#667085!important;}
.rmc-preview-message-copy #rmc-preview-greeting-text{display:block;overflow-wrap:anywhere;}

/* Final overview parity: keep preview colors and controls identical to the editor. */
#rmc-dashboard-chat{--p1:<?=$color?>;--p2:<?=$headerColor2?>;background:#f7f8fc!important}
#rmc-dashboard-chat .rmc-preview-message.outgoing .rmc-bubble.out{background:linear-gradient(135deg,var(--p1),var(--p2))!important;color:#fff!important;border-color:transparent!important;box-shadow:none!important}
/* In both previews, show the launcher image without the palette-colored tile behind it. */
#rmc-dashboard-device>.rmc-preview-button,
#rmc-preview-device>.rmc-preview-button{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;box-shadow:none!important;border-radius:0!important}
#rmc-dashboard-device>.rmc-preview-button>.rmc-admin-preview-button-crop,
#rmc-preview-device>.rmc-preview-button>.rmc-admin-preview-button-crop{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;box-shadow:none!important}
#rmc-dashboard-chat .rmc-preview-attach,#rmc-dashboard-chat .rmc-preview-send{appearance:none!important;background:linear-gradient(135deg,var(--p1),var(--p2))!important;color:#fff!important;border:0!important;border-radius:12px!important;box-shadow:0 5px 14px rgba(71,26,255,.18)!important;cursor:default!important}
#rmc-dashboard-chat .rmc-preview-attach:hover,#rmc-dashboard-chat .rmc-preview-send:hover{filter:brightness(1.04)}
#rmc-dashboard-chat .rmc-preview-attach svg,#rmc-dashboard-chat .rmc-preview-send svg{width:19px!important;height:19px!important;display:block!important;stroke:#fff!important;fill:none!important;stroke-width:1.8!important;stroke-linecap:round!important;stroke-linejoin:round!important}
#rmc-dashboard-head .rmc-preview-window-actions{z-index:2!important}
#rmc-dashboard-head .rmc-preview-window-actions button{appearance:none!important;box-sizing:border-box!important;cursor:default!important;box-shadow:0 1px 3px rgba(0,0,0,.08)!important}
#rmc-dashboard-head .rmc-preview-window-actions button svg{display:block!important;width:15px!important;height:15px!important;fill:none!important;stroke:currentColor!important;stroke-width:1.8!important;stroke-linecap:round!important;stroke-linejoin:round!important}
#rmc-dashboard-head .rmc-preview-window-actions button:last-child{font-family:Arial,sans-serif!important;font-weight:400!important}
/* Final launcher cleanup on Overview: remove the palette tile, keep only the icon and online indicator. */
#rmc-dashboard-device .rmc-preview-button,
#rmc-dashboard-device .rmc-preview-button:hover,
#rmc-dashboard-device .rmc-preview-button:focus,
#rmc-dashboard-device .rmc-preview-button:active{background:none!important;background-color:transparent!important;background-image:none!important;border:0!important;outline:0!important;box-shadow:none!important}
#rmc-dashboard-device .rmc-preview-button>.rmc-admin-preview-button-crop,
#rmc-dashboard-device .rmc-preview-button>.rmc-admin-preview-button-crop img{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;box-shadow:none!important}
#rmc-dashboard-device .rmc-preview-button:after{background:#22c55e!important;border:3px solid #fff!important;box-shadow:0 2px 6px rgba(16,24,40,.14)!important}
#rmc-dashboard-chat .rmc-preview-message.outgoing .rmc-bubble.out{background:linear-gradient(135deg,<?=$color?> 0%,<?=$color?> 55%,<?=$headerColor2?> 100%)!important;background-color:<?=$color?>!important;color:#fff!important;border:0!important;border-color:transparent!important}
#rmc-dashboard-chat .rmc-preview-message.outgoing .rmc-bubble.out{--rmc-overview-client-color:<?=$color?>;--rmc-overview-client-color-2:<?=$headerColor2?>}
/* Hard reset launcher tile in Overview; only the uploaded icon and status dot remain visible. */
#rmc-dashboard-device .rmc-preview-button,
#rmc-dashboard-device .rmc-preview-button:hover,
#rmc-dashboard-device .rmc-preview-button:focus,
#rmc-dashboard-device .rmc-preview-button:active{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;box-shadow:none!important;filter:none!important;}
#rmc-dashboard-device .rmc-preview-button:before{content:none!important;display:none!important;background:none!important;box-shadow:none!important;}
#rmc-dashboard-device .rmc-preview-button>.rmc-admin-preview-button-crop,
#rmc-dashboard-device .rmc-preview-button>.rmc-admin-preview-button-crop img{background:transparent!important;background-color:transparent!important;background-image:none!important;border:0!important;box-shadow:none!important;}


/* Professional editor system: consistent rhythm, aligned controls, polished sliders. */
.rmc-widget-editor{--editor-gap:16px;align-items:start;gap:22px!important}
.rmc-widget-editor>div:first-child{min-width:0}
.rmc-widget-editor .rmc-panel{padding:24px!important;margin:0 0 18px!important;border:1px solid #e4e7ef!important;border-radius:18px!important;background:#fff!important;box-shadow:0 4px 18px rgba(16,24,40,.045)!important}
.rmc-widget-editor .rmc-panel h2{display:flex;align-items:center;gap:9px;margin:0 0 7px!important;font-size:17px!important;line-height:1.35!important;letter-spacing:-.25px;color:#171a2b!important}
.rmc-widget-editor .rmc-panel .desc{margin:0 0 22px!important;color:#778096!important;font-size:12.5px!important;line-height:1.55!important}
.rmc-widget-editor .rmc-fields{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:20px 16px!important;align-items:start}
.rmc-widget-editor .rmc-field{display:flex;flex-direction:column;align-items:stretch;gap:0;min-width:0}
.rmc-widget-editor .rmc-field>label{display:flex;align-items:center;justify-content:flex-start;flex-wrap:wrap;gap:5px;margin:0 0 8px!important;min-height:19px;font-size:12.5px!important;font-weight:700!important;line-height:1.45!important;color:#344054!important}
.rmc-widget-editor .rmc-field .rmc-help{margin-top:7px!important;font-size:11.5px!important;line-height:1.5!important;color:#8991a4!important}
.rmc-widget-editor .rmc-field input[type=text],.rmc-widget-editor .rmc-field input[type=password],.rmc-widget-editor .rmc-field input[type=number],.rmc-widget-editor .rmc-field input[type=time],.rmc-widget-editor .rmc-field textarea,.rmc-widget-editor .rmc-field select{min-width:0;width:100%;height:44px;box-sizing:border-box;border:1px solid #dfe3eb;border-radius:11px;background:#fff;padding:0 12px;color:#202437;font:500 13px/1.4 Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;box-shadow:0 1px 2px rgba(16,24,40,.025);transition:border-color .18s,box-shadow .18s,background .18s}
.rmc-widget-editor .rmc-field textarea{height:auto;min-height:96px;padding:12px;line-height:1.5}
.rmc-widget-editor .rmc-field input:hover,.rmc-widget-editor .rmc-field textarea:hover,.rmc-widget-editor .rmc-field select:hover{border-color:#cbd2e0}
.rmc-widget-editor .rmc-field input:focus,.rmc-widget-editor .rmc-field textarea:focus,.rmc-widget-editor .rmc-field select:focus{border-color:#8b78ff;outline:0;box-shadow:0 0 0 3px rgba(101,76,255,.11)}
.rmc-widget-editor .rmc-field.full{grid-column:1/-1}
.rmc-widget-editor .rmc-upload-card{gap:15px;min-height:100px;padding:14px;border:1px solid #e3e7ef;border-radius:14px;background:linear-gradient(180deg,#fcfcfe,#f8f9fc)}
.rmc-widget-editor .rmc-upload-card>img,.rmc-widget-editor .rmc-admin-crop-frame{width:66px;height:66px;flex:0 0 66px;border-radius:13px;border:1px solid #e1e5ee;background:#fff;box-shadow:0 2px 5px rgba(16,24,40,.035)}
.rmc-widget-editor .rmc-upload-content{gap:7px}
.rmc-widget-editor .rmc-upload-content strong{font-size:12.5px;font-weight:750;color:#30364a}
.rmc-widget-editor .rmc-file-control{height:auto!important;min-height:34px!important;padding:0!important;font-size:12px!important}
.rmc-widget-editor .rmc-file-control::file-selector-button{height:34px;border:1px solid #d9deea;border-radius:9px;background:#fff;color:#41485b;padding:0 12px;font-size:12px;font-weight:700;transition:background .15s,border-color .15s}
.rmc-widget-editor .rmc-file-control::file-selector-button:hover{background:#f5f3ff;border-color:#c9c0ff}
.rmc-widget-editor .rmc-crop-controls{margin-top:16px!important;padding:16px;border:1px solid #edf0f5;border-radius:13px;background:#fbfcfe;gap:16px!important}
.rmc-widget-editor .rmc-crop-controls .rmc-field{gap:0}
.rmc-widget-editor input[type=range]{display:block;width:100%;height:24px;min-height:24px;margin:2px 0 0;padding:0;appearance:none;-webkit-appearance:none;background:transparent;accent-color:#654cff;cursor:pointer;border:0;box-shadow:none}
.rmc-widget-editor input[type=range]::-webkit-slider-runnable-track{height:5px;border-radius:99px;background:linear-gradient(90deg,#654cff,#9b8aff)}
.rmc-widget-editor input[type=range]::-moz-range-track{height:5px;border-radius:99px;background:linear-gradient(90deg,#654cff,#9b8aff)}
.rmc-widget-editor input[type=range]::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:17px;height:17px;margin-top:-6px;border:3px solid #fff;border-radius:50%;background:#654cff;box-shadow:0 1px 5px rgba(50,36,130,.28)}
.rmc-widget-editor input[type=range]::-moz-range-thumb{width:12px;height:12px;border:3px solid #fff;border-radius:50%;background:#654cff;box-shadow:0 1px 5px rgba(50,36,130,.28)}
.rmc-widget-editor .rmc-range{min-height:44px;gap:12px;padding:0 12px;border:1px solid #e1e5ed;border-radius:11px;background:#fafbfe;box-shadow:none}
.rmc-widget-editor .rmc-range input[type=range]{flex:1;min-width:0}
.rmc-widget-editor .rmc-range output,.rmc-widget-editor .rmc-field label output{display:inline-flex;align-items:center;justify-content:center;min-width:44px;height:26px;padding:0 7px;border:1px solid #e6e1ff;border-radius:8px;background:#f4f1ff;color:#5b45d6;font-size:11.5px;font-weight:750;line-height:1;box-sizing:border-box}
/* Values are already shown beside each slider label; hide duplicate value badges on the right of every slider. Keep output nodes for JS synchronization. */
.rmc-widget-editor .rmc-range output{display:none!important;}
.rmc-widget-editor .rmc-color-controls{gap:9px}
.rmc-widget-editor .rmc-color-controls .rmc-color{width:48px;height:44px;flex:0 0 48px;padding:4px!important;border:1px solid #dfe3eb;border-radius:11px;box-shadow:0 1px 2px rgba(16,24,40,.03)}
.rmc-widget-editor .rmc-color-code{width:120px;height:44px;border-radius:11px;font-size:12.5px}
.rmc-widget-editor .rmc-position{gap:10px}
.rmc-widget-editor .rmc-position-option{height:44px;min-height:44px;padding:0 12px;border-radius:11px;background:#fafbfe;font-size:12.5px;font-weight:650}
.rmc-widget-editor .rmc-position-option:has(input:checked){border-color:#b7aaff;background:#f4f1ff;color:#4f36cb;box-shadow:inset 0 0 0 1px rgba(101,76,255,.05)}
.rmc-widget-editor .rmc-actions{display:flex;align-items:center;gap:10px;margin-top:24px!important;padding-top:18px;border-top:1px solid #eef0f5}
.rmc-widget-editor .rmc-primary,.rmc-widget-editor .rmc-secondary{min-height:44px;padding:0 19px;border-radius:11px;font-size:13px;font-weight:750;transition:transform .15s,box-shadow .15s,background .15s}
.rmc-widget-editor .rmc-primary{box-shadow:0 5px 12px rgba(71,26,255,.17)}
.rmc-widget-editor .rmc-primary:hover{transform:translateY(-1px);box-shadow:0 8px 17px rgba(71,26,255,.22)}
.rmc-widget-editor .rmc-radius-control.is-disabled{opacity:.56}
.rmc-widget-editor .rmc-radius-control.is-disabled .rmc-range{background:#f0f2f6;border-color:#e4e7ee}
.rmc-widget-editor .rmc-radius-control.is-disabled input[type=range]{cursor:not-allowed;filter:grayscale(1)}
.rmc-widget-editor .rmc-preview{padding:20px!important;border-radius:18px!important}
.rmc-widget-editor .rmc-preview h3{margin-bottom:7px!important}
.rmc-widget-editor .rmc-device{margin-top:16px!important;border-radius:18px!important}
@media(max-width:900px){.rmc-widget-editor{grid-template-columns:minmax(0,1fr)!important}.rmc-widget-editor .rmc-preview{position:relative;top:auto;min-height:0}.rmc-widget-editor .rmc-device{max-width:420px;margin-left:auto!important;margin-right:auto!important}}
.rmc-emoji-tools{margin-top:9px;padding:10px 12px;border:1px solid #e5eaf2;border-radius:12px;background:#f8fafc;display:flex;flex-direction:column;gap:8px}.rmc-emoji-tools>span{font-size:12px;font-weight:650;color:#475467}.rmc-emoji-list{display:flex;flex-wrap:wrap;gap:5px}.rmc-emoji-btn{width:34px;height:34px;border:1px solid #e1e7f0;border-radius:9px;background:#fff;font-size:19px;line-height:1;cursor:pointer;transition:background .15s,border-color .15s,transform .15s}.rmc-emoji-btn:hover{background:#eef2ff;border-color:#a5b4fc;transform:translateY(-1px)}.rmc-emoji-btn:focus-visible{outline:2px solid #6366f1;outline-offset:2px}.rmc-emoji-tools small{font-size:11px;color:#667085;line-height:1.45}@media(max-width:600px){.rmc-widget-editor .rmc-panel{padding:17px!important}.rmc-widget-editor .rmc-fields{grid-template-columns:minmax(0,1fr)!important;gap:17px!important}.rmc-widget-editor .rmc-field.full{grid-column:1}.rmc-widget-editor .rmc-crop-controls{padding:12px}.rmc-widget-editor .rmc-upload-card{align-items:flex-start}.rmc-widget-editor .rmc-color-controls{flex-wrap:wrap}.rmc-widget-editor .rmc-actions>*{width:100%}}

.rmc-reset-panel{border-color:#f1c8c5!important;background:linear-gradient(180deg,#fff,#fffafa)!important}.rmc-reset-panel h2{color:#912018!important}.rmc-reset-panel .desc{max-width:780px}.rmc-danger-button{background:linear-gradient(135deg,#b42318,#d92d20)!important;box-shadow:0 6px 16px rgba(180,35,24,.16)!important;color:#fff!important}
</style>
<?php elseif ($activeTab === 'advanced'): ?>
  <form method="post" enctype="multipart/form-data"><input type="hidden" name="sessid" value="<?=bitrix_sessid()?>"><input type="hidden" name="action" value="save"><input type="hidden" name="tab" value="advanced">
    <div class="rmc-panel"><h2>Дополнительные параметры</h2><div class="desc">Служебные параметры модуля.</div><div class="rmc-fields"><div class="rmc-field"><label>Виджет на сайте</label><div class="rmc-switch"><input type="checkbox" name="enabled" value="Y" <?=Settings::enabled()?'checked':''?>><span>Показывать посетителям</span></div></div></div><div class="rmc-actions"><button class="rmc-primary">Сохранить</button></div></div>
  </form>
  <div class="rmc-panel rmc-reset-panel"><h2>Сброс всех настроек</h2><div class="desc">Полностью очистит настройки редактора виджета и подключения MAX: токен, ID чата, секрет Webhook, цвета, тексты, изображения, размеры и остальные параметры. История переписки и сохранённые сообщения останутся без изменений.</div><form method="post" onsubmit="return confirm('Сбросить ВСЕ настройки виджета и подключения MAX? Токен и параметры оформления будут удалены. История чатов останется. Это действие нельзя отменить.');"><input type="hidden" name="sessid" value="<?=bitrix_sessid()?>"><input type="hidden" name="action" value="reset_all"><input type="hidden" name="tab" value="advanced"><div class="rmc-actions"><button class="rmc-primary rmc-danger-button" type="submit">Сбросить все настройки</button></div></form></div>
<?php endif; ?>
</div>
<script>
(function(){
 var $=function(id){return document.getElementById(id)};
 var greetingField=$('rmc-greeting');
 document.querySelectorAll('.rmc-emoji-btn[data-emoji]').forEach(function(btn){btn.addEventListener('click',function(){if(!greetingField)return;var emoji=btn.getAttribute('data-emoji')||'',start=greetingField.selectionStart==null?greetingField.value.length:greetingField.selectionStart,end=greetingField.selectionEnd==null?start:greetingField.selectionEnd;greetingField.setRangeText(emoji,start,end,'end');greetingField.focus();greetingField.dispatchEvent(new Event('input',{bubbles:true}));});});
 function installShapePicker(select){
   if(!select||select.dataset.customPicker==='Y')return;
   select.dataset.customPicker='Y';var wrap=document.createElement('div');wrap.className='rmc-shape-picker';select.parentNode.insertBefore(wrap,select);wrap.appendChild(select);
   var trigger=document.createElement('button');trigger.type='button';trigger.className='rmc-shape-trigger';trigger.setAttribute('aria-haspopup','listbox');trigger.setAttribute('aria-expanded','false');
   var menu=document.createElement('div');menu.className='rmc-shape-menu';menu.setAttribute('role','listbox');
   function shapeName(value){return value==='circle'?'Круг':'Квадрат'}
   function glyph(value){var g=document.createElement('span');g.className='rmc-shape-glyph'+(value==='circle'?' circle':'');return g}
   function refresh(){var value=select.value;trigger.innerHTML='';var left=document.createElement('span');left.className='rmc-shape-trigger-label';left.appendChild(glyph(value));var label=document.createElement('span');label.textContent=shapeName(value);left.appendChild(label);trigger.appendChild(left);var svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('class','rmc-shape-chevron');svg.innerHTML='<path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';trigger.appendChild(svg);Array.prototype.forEach.call(menu.querySelectorAll('.rmc-shape-option'),function(b){b.setAttribute('aria-selected',b.dataset.value===value?'true':'false');});}
   Array.prototype.forEach.call(select.options,function(option){var b=document.createElement('button');b.type='button';b.className='rmc-shape-option';b.dataset.value=option.value;b.setAttribute('role','option');b.appendChild(glyph(option.value));var label=document.createElement('span');label.textContent=shapeName(option.value);b.appendChild(label);var check=document.createElement('span');check.className='rmc-shape-check';check.textContent='✓';b.appendChild(check);b.addEventListener('click',function(){select.value=option.value;select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));wrap.classList.remove('is-open');trigger.setAttribute('aria-expanded','false');refresh();trigger.focus();});menu.appendChild(b);});
   trigger.addEventListener('click',function(){var open=!wrap.classList.contains('is-open');document.querySelectorAll('.rmc-shape-picker.is-open').forEach(function(el){el.classList.remove('is-open');var t=el.querySelector('.rmc-shape-trigger');if(t)t.setAttribute('aria-expanded','false');});if(open){wrap.classList.add('is-open');trigger.setAttribute('aria-expanded','true');}});
   select.addEventListener('change',refresh);wrap.appendChild(trigger);wrap.appendChild(menu);refresh();
 }
 installShapePicker($('rmc-avatar-shape'));installShapePicker($('rmc-button-icon-shape'));
 document.addEventListener('click',function(e){document.querySelectorAll('.rmc-shape-picker.is-open').forEach(function(el){if(!el.contains(e.target)){el.classList.remove('is-open');var t=el.querySelector('.rmc-shape-trigger');if(t)t.setAttribute('aria-expanded','false');}});});
 document.addEventListener('keydown',function(e){if(e.key==='Escape'){document.querySelectorAll('.rmc-shape-picker.is-open').forEach(function(el){el.classList.remove('is-open');var t=el.querySelector('.rmc-shape-trigger');if(t)t.setAttribute('aria-expanded','false');});}});
 function sync(){
   var c=$('rmc-color'),cp=$('rmc-color-picker'),c2=$('rmc-color2-code'),c2p=$('rmc-color2'),s=$('rmc-size'),r=$('rmc-radius');
   if(!c||!s||!r)return;
   var color=(c&&/^#[0-9a-fA-F]{6}$/.test(c.value)?c.value.toLowerCase():(cp&&cp.value)||'#471AFF'), color2=(c2&&/^#[0-9a-fA-F]{6}$/.test(c2.value)?c2.value.toLowerCase():(c2p&&c2p.value)||'#00BFFF');
   var head=$('rmc-preview-head'),btn=$('rmc-preview-button'),chat=$('rmc-preview-chat'),body=$('rmc-preview-body');
   var gradient='linear-gradient(135deg,'+color+' 0%,'+color+' 55%,'+color2+' 100%)';
   var shapeControl=$('rmc-button-icon-shape'),radiusControl=$('rmc-radius-control'),radiusDisabled=!!(shapeControl&&shapeControl.value==='circle');
   r.disabled=radiusDisabled;if(radiusControl)radiusControl.classList.toggle('is-disabled',radiusDisabled);
   var radiusOut=$('rmc-radius-out'),radiusOut2=$('rmc-radius-out2');
   if(radiusDisabled){if(radiusOut)radiusOut.textContent='Недоступно';if(radiusOut2)radiusOut2.textContent='Недоступно';}else{if(radiusOut)radiusOut.textContent=r.value;if(radiusOut2)radiusOut2.textContent=r.value;}
   [chat,body,head].forEach(function(el){if(el){el.style.setProperty('--p1',color);el.style.setProperty('--p2',color2);}});
   if(head){head.style.background=gradient;}
   if(btn){btn.style.setProperty('--p1',color);btn.style.setProperty('--p2',color2);btn.style.background=gradient;btn.style.width=s.value+'px';btn.style.height=s.value+'px';var bi=btn.querySelector('img');if(bi){bi.style.width='100%';bi.style.height='100%';}btn.style.setProperty('--rad',r.value+'px');}
   var send=$('rmc-preview-send'),attach=document.querySelector('.rmc-preview-attach');
   [send,attach].forEach(function(el){if(el){el.style.setProperty('--p1',color);el.style.setProperty('--p2',color2);el.style.background=gradient;}});
   var statusDot=$('rmc-preview-status-dot');
   var dashboardBubble=document.querySelector('#rmc-dashboard-chat .rmc-preview-message.outgoing .rmc-bubble.out');
   if(dashboardBubble){dashboardBubble.style.setProperty('background','linear-gradient(135deg,'+color+' 0%,'+color+' 55%,'+color2+' 100%)','important');dashboardBubble.style.setProperty('background-color',color,'important');dashboardBubble.style.setProperty('color','#fff','important');}
   var dashboardButton=$('rmc-dashboard-device')&&$('rmc-dashboard-device').querySelector('.rmc-preview-button');
   if(dashboardButton){['background','background-color','background-image','border','box-shadow','filter'].forEach(function(prop){dashboardButton.style.setProperty(prop,prop==='background'||prop==='background-color'?'transparent':'none','important');});}

   function crop(prefix, previewIds, smallIds){
     var shape=$(prefix+'-shape'),zoom=$(prefix+'-zoom'),x=$(prefix+'-x'),y=$(prefix+'-y');
     var radius=shape&&shape.value==='circle'?'50%':(prefix==='rmc-button-icon'?(r.value+'px'):'12px'),scale=(zoom?Number(zoom.value):100)/100,pos=(x?x.value:50)+'% '+(y?y.value:50)+'%';
     previewIds.forEach(function(id){var el=$(id);if(el){var frame=el.parentElement;if(frame&&(frame.classList.contains('rmc-admin-crop-frame')||frame.classList.contains('rmc-admin-preview-crop')||frame.classList.contains('rmc-admin-preview-button-crop')||frame.classList.contains('rmc-preview-message-avatar'))){frame.style.borderRadius=radius;frame.style.overflow='hidden';el.style.borderRadius='0';el.style.width='100%';el.style.height='100%';}else{el.style.borderRadius=radius;}el.style.objectFit='cover';el.style.objectPosition=pos;el.style.transform='scale('+scale+')';el.style.transformOrigin=pos;}});
     smallIds.forEach(function(id){var el=$(id);if(el){el.textContent=(zoom&&id.indexOf('zoom-out')>=0?zoom.value:x&&id.indexOf('-x-out')>=0?x.value:y?y.value:'')+'%';}});
   }
   crop('rmc-avatar',['rmc-avatar-preview','rmc-preview-avatar','rmc-preview-message-avatar'],['rmc-avatar-zoom-out','rmc-avatar-x-out','rmc-avatar-y-out']);
   crop('rmc-button-icon',['rmc-button-icon-preview','rmc-preview-button-icon'],['rmc-button-icon-zoom-out','rmc-button-icon-x-out','rmc-button-icon-y-out']);
   var avatarShape=$('rmc-avatar-shape'), buttonShape=$('rmc-button-icon-shape'), headCrop=$('rmc-preview-avatar')&&$('rmc-preview-avatar').parentElement, previewColor=(c&&/^#[0-9a-fA-F]{6}$/.test(c.value)?c.value:'#471AFF');
   if(headCrop){headCrop.style.borderRadius=avatarShape&&avatarShape.value==='circle'?'50%':'0px';headCrop.style.background='transparent';headCrop.style.border='1px solid '+previewColor;headCrop.style.boxSizing='border-box';}var msgAvatarFrame=document.querySelector('.rmc-preview-message-avatar');if(msgAvatarFrame){msgAvatarFrame.style.borderRadius=avatarShape&&avatarShape.value==='circle'?'50%':'0px';msgAvatarFrame.style.setProperty('--rmc-preview-avatar-radius',avatarShape&&avatarShape.value==='circle'?'50%':'0px');}
   var title=$('rmc-preview-title'),sub=$('rmc-preview-subtitle'),g=$('rmc-preview-greeting-text'),mn=$('rmc-preview-manager-name');
   if(title)title.textContent=$('rmc-title').value;
   var startField=$('rmc-work-start'),endField=$('rmc-work-end');
   var startTime=(startField&&startField.value)||'09:00',endTime=(endField&&endField.value)||'17:00';
   var now=new Date(),nowM=now.getHours()*60+now.getMinutes();
   var startParts=startTime.split(':').map(Number),endParts=endTime.split(':').map(Number);
   var startM=startParts[0]*60+startParts[1],endM=endParts[0]*60+endParts[1];
   var online=startM<=endM?(nowM>=startM&&nowM<endM):(nowM>=startM||nowM<endM);
   if(sub)sub.textContent=online?'Операторы онлайн':'Операторы оффлайн';
   var dot=$('rmc-preview-status-dot');if(dot){dot.classList.toggle('is-offline',!online);}if(btn){btn.classList.toggle('is-offline',!online);}
   if(g)g.textContent=online?$('rmc-greeting').value:'Мы не в сети, но вы можете написать нам. Ответим в рабочее время: с '+startTime+' до '+endTime+'.';
   if(mn)mn.textContent=$('rmc-manager-name').value||'Администратор';
   var so=$('rmc-size-out'),so2=$('rmc-size-out2'),ro=$('rmc-radius-out'),ro2=$('rmc-radius-out2');
   if(so)so.value=s.value;if(so2)so2.value=s.value;if(!radiusDisabled){if(ro)ro.value=r.value;if(ro2)ro2.value=r.value;}
 }
 ['rmc-avatar-shape','rmc-button-icon-shape','rmc-color','rmc-color-picker','rmc-color2-code','rmc-color2','rmc-size','rmc-radius','rmc-title','rmc-greeting','rmc-manager-name','rmc-work-start','rmc-work-end'].forEach(function(id){var e=$(id);if(e){e.addEventListener('input',function(){var value=e.value;if(id==='rmc-color'&&/^#[0-9a-fA-F]{6}$/.test(value)&&$('rmc-color-picker'))$('rmc-color-picker').value=value;if(id==='rmc-color-picker'&&$('rmc-color'))$('rmc-color').value=value;if(id==='rmc-color2-code'&&/^#[0-9a-fA-F]{6}$/.test(value)&&$('rmc-color2'))$('rmc-color2').value=value;if(id==='rmc-color2'&&$('rmc-color2-code'))$('rmc-color2-code').value=value;sync();});e.addEventListener('change',function(){if((id==='rmc-color'||id==='rmc-color2-code')&&!/^#[0-9a-fA-F]{6}$/.test(e.value)){e.setCustomValidity('Введите цвет в формате #8b5cf6');e.reportValidity();return;}e.setCustomValidity('');sync();});}});
 ['avatar_shape','avatar_zoom','avatar_x','avatar_y','button_icon_shape','button_icon_zoom','button_icon_x','button_icon_y'].forEach(function(name){document.querySelectorAll('[name="'+name+'"]').forEach(function(e){e.addEventListener('input',sync);e.addEventListener('change',sync);});});
 ['position','button_text','offset_x','offset_y'].forEach(function(name){document.querySelectorAll('[name="'+name+'"]').forEach(function(e){e.addEventListener('input',sync);e.addEventListener('change',sync);});});
 var bif=$('rmc-button-icon-file');
 if(bif){bif.addEventListener('change',function(){var file=bif.files&&bif.files[0];if(file&&file.type.indexOf('image/')===0){var reader=new FileReader();reader.onload=function(){var src=reader.result,p=$('rmc-button-icon-preview'),b=$('rmc-preview-button-icon');if(p)p.src=src;if(b)b.src=src;};reader.readAsDataURL(file);}});}
 var af=$('rmc-avatar-file');
 if(af){af.addEventListener('change',function(){var file=af.files&&af.files[0];if(file&&file.type.indexOf('image/')===0){var reader=new FileReader();reader.onload=function(){var src=reader.result;var p=$('rmc-avatar-preview'),h=$('rmc-preview-avatar'),m=$('rmc-preview-message-avatar');if(p)p.src=src;if(h)h.src=src;if(m)m.src=src;};reader.readAsDataURL(file);}});}
 sync();
 window.setInterval(sync,10000);
})();

</script>
<style>/* v0.4.34: Force white expand/close icons in Overview preview */
#rmc-dashboard-head .rmc-preview-window-actions button{width:32px!important;height:32px!important;flex:0 0 32px!important;border-radius:9px!important;background:rgba(255,255,255,.14)!important;color:#fff!important;font-size:23px!important}
#rmc-dashboard-head .rmc-preview-window-actions button{color:#fff!important;-webkit-text-fill-color:#fff!important}
#rmc-dashboard-head .rmc-preview-window-actions button svg{width:17px!important;height:17px!important;display:block!important;fill:none!important;stroke:#fff!important;stroke-width:1.8!important;stroke-linecap:round!important;stroke-linejoin:round!important}
#rmc-dashboard-head .rmc-preview-window-actions button svg path{stroke:#fff!important;fill:none!important}
#rmc-dashboard-head .rmc-preview-window-actions button:first-child{color:#fff!important;background:rgba(255,255,255,.14)!important}
#rmc-dashboard-status-dot.is-offline{background:#ef4444!important;box-shadow:0 0 0 2px rgba(239,68,68,.16)!important}
#rmc-dashboard-status-dot.is-offline:before,#rmc-dashboard-status-dot.is-offline:after{border-color:rgba(239,68,68,.8)!important}
#rmc-dashboard-device>.rmc-preview-button.is-offline:after{background:#ef4444!important}
</style>

<?php require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';

