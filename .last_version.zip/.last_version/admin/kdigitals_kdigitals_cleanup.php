<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php';
if (!$USER->IsAdmin()) {
    require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';
    die();
}
if (!check_bitrix_sessid()) {
    require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';
    die('Недействительная сессия.');
}
$db = \Bitrix\Main\Application::getConnection();
foreach (['kdigitals_kdigitals_message','kdigitals_kdigitals_conversation','kdigitals_kdigitals_visitor','kdigitals_kdigitals_chat'] as $table) {
    try { $db->queryExecute('DROP TABLE IF EXISTS '.$table); } catch (\Throwable $e) {}
}
@unlink(__FILE__);
$APPLICATION->SetTitle('Онлайн-чат МАКС — данные удалены');
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php';
$adminUrl='/bitrix/admin/';
?>
<style>.rmc-clean{max-width:720px;margin:40px auto;font-family:Arial,sans-serif}.rmc-clean-card{overflow:hidden;background:#fff;border:1px solid #e7e3ef;border-radius:26px;box-shadow:0 22px 65px rgba(13,0,26,.15)}.rmc-clean-top{padding:34px;background:linear-gradient(135deg,#471AFF,#9500FF);color:#fff}.rmc-clean-icon{font-size:46px}.rmc-clean-title{font-size:28px;font-weight:800;margin-top:10px}.rmc-clean-body{padding:34px}.rmc-clean-body p{color:#5f5a69;line-height:1.65}.rmc-clean-btn{display:inline-block;margin-top:18px;padding:13px 20px;border-radius:13px;background:#471AFF;color:#fff!important;text-decoration:none!important;font-weight:800}</style>
<div class="rmc-clean"><div class="rmc-clean-card"><div class="rmc-clean-top"><div class="rmc-clean-icon">✓</div><div class="rmc-clean-title">Данные удалены</div></div><div class="rmc-clean-body"><p>История обращений, посетители, сообщения и связанные данные Онлайн-чата МАКС полностью удалены из базы данных.</p><a class="rmc-clean-btn" href="<?=$adminUrl?>">Вернуться в административную панель</a></div></div></div>
<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';
