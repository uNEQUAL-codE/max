<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php';
use Bitrix\Main\Loader; use Resurs\Kdigitals\Model\ConversationTable; use Resurs\Kdigitals\Model\MessageTable;
if(!Loader::includeModule('kdigitals.max')){require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';return;}

// Защита списка обращений: доступ только администраторам
// или пользователям с правом записи в модуль.
global $USER, $APPLICATION;
if ((!is_object($USER) || !$USER->IsAdmin())
    && $APPLICATION->GetGroupRight('kdigitals.max') < 'W') {
    $APPLICATION->AuthForm(GetMessage('ACCESS_DENIED'));
    exit;
}
$APPLICATION->SetTitle('Онлайн-чат МАКС');
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php';
$convs=ConversationTable::getList(['order'=>['UPDATED_AT'=>'DESC'],'limit'=>50])->fetchAll();
?><div style="padding:18px;max-width:1200px"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px"><div><h2 style="margin:0 0 6px">Онлайн-чат МАКС</h2><div style="color:#667085">Обращения посетителей сайта → приватный чат/канал MAX</div></div><a class="adm-btn" href="/bitrix/admin/kdigitals_kdigitals_settings.php">⚙ Настройки</a></div><table class="adm-list-table" style="width:100%"><tr class="adm-list-table-header"><td>ID</td><td>Сайт</td><td>MAX chat</td><td>Статус</td><td>Страница</td><td>Обновлено</td></tr><?php foreach($convs as $c):?><tr><td><?=$c['ID']?></td><td><?=htmlspecialcharsbx($c['SITE_ID'])?></td><td><?=htmlspecialcharsbx($c['MAX_CHAT_ID'])?></td><td><?=htmlspecialcharsbx($c['STATUS'])?></td><td><?=htmlspecialcharsbx($c['PAGE_URL'])?></td><td><?=htmlspecialcharsbx((string)$c['UPDATED_AT'])?></td></tr><?php endforeach;?></table></div><?php require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php';
